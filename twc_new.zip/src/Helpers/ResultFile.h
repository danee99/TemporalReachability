#ifndef CENTRALITY_RESULTFILE_H
#define CENTRALITY_RESULTFILE_H

#include <utility>
#include <string>
#include "TemporalGraph/TemporalGraphs.h"
#include "TopkResult.h"

class ResultFile {

public:

    explicit ResultFile(std::string dn) : datasetname(std::move(dn)) {}

    std::vector<std::pair<NodeId, double>>& getResults() {
        return results;
    }

    void save();

    bool load();

    Result compare(std::vector<std::pair<NodeId, double>> &results, unsigned int k);

    Result compareCover(std::vector<std::pair<NodeId, double>> &results, unsigned int k);

    bool loadReach();

private:

    std::string datasetname;

    std::vector<std::pair<NodeId, double>> results;

};


#endif //CENTRALITY_RESULTFILE_H

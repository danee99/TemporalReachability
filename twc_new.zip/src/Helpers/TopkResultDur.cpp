#include "TopkResultDur.h"

using namespace std;

void TopkResultDur::insert(Time dur) {
    if (doApproximation() && minMaxTopK < dur)
        return;

    auto p = topk.insert(dur);

    if (minMaxTopK > dur && topk.size() > k) {
        auto i = topk.find(minMaxTopK);
        if (i != topk.end()) {
            topk.erase(i);
        }
    }

    minMaxTopK = *topk.rbegin();
}



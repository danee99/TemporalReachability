#include "TopkResult.h"
#include "SGLog.h"
#include "HelperFunctions.h"

using namespace std;

void TopkResult::insert(double closeness, NodeId nid) {
    if (doApproximation() && minMaxTopK > closeness)
        return;

    auto p = topk.insert(TopKEntry(closeness, nid));
    if (!p.second) {
        const_cast<std::vector<NodeId>&>(p.first->nids).push_back(nid);
    }

    if (minMaxTopK < closeness && topk.size() > k) {
        auto i = topk.find(TopKEntry(minMaxTopK, 0));
        if (i != topk.end()) {
            topk.erase(i);
        }
    }

    minMaxTopK = topk.rbegin()->closeness;
}

void TopkResult::print() {
    SGLog::log() << getResultString();
}

string TopkResult::getResultString() {
    string result;
    unsigned int max_lines = 12;
    for (auto &e : topk) {
        result.append(to_string(e.closeness) + "\t" + to_string((double)e.closeness / h) + "\t");
        for (auto &n : e.nids) {
            result.append(to_string(n) + " ");
            allnids.push_back(n);
        }
        result.append("\n");
        max_lines--;
        if (max_lines == 0) {
            result.append("...\n");
            return result;
        }
    }
    return result;
}

string TopkResult::countTopkSet(TopkResult &result) {
    unsigned int found = 0;
    unsigned int total = 0;
    unsigned int total2 = 0;
    for (auto &e : topk) {
        for (auto &n : e.nids) {
            for (auto &f : result.topk) {
                for (auto &m : f.nids) {
//                    cout << n << " " << m << endl;
                    if (n == m) ++found;
                }
            }
            ++total;
        }
    }
    for (auto &f : result.topk) {
        for (auto &m : f.nids) {
            ++total2;
        }
    }
    double jaccard = (double)found / (double)(total + total2 - found);
    SGLog::log() << "Count top k set equality\n";
    SGLog::log() << total << "\t" << total2 << "\t" << found << "\t Jaccard: " << jaccard << "\n";
//    SGLog::log() << total << "\t" << total2 << "\t" << found << "\t" << ((double)found / total) << "\t" << jaccard << "\n";
//    result.print();
//    print();
    return "Jaccard: " + to_string(jaccard);
}

void TopkResult::printAllNids(const std::string& filename) {
    HF::writeVectorToFile(filename, allnids);
}

std::vector<std::pair<NodeId, double>> TopkResult::getResults() {
    std::vector<std::pair<NodeId, double>> results;
    for (auto &p : topk) {
        for (auto &n : p.nids) {
            results.emplace_back(n, p.closeness);
        }
    }
    return results;
}

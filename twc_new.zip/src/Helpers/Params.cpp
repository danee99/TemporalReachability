#include "Params.h"
#include "SGLog.h"

using namespace std;

void show_help() {
    cout << "Usage: Centrality [dataset] [mode]" << endl;
    cout << "Optional: [-k=top k] [-i= interval size <= 1] [-p=sampling/approx. size <= 1] [-f= nids file] [-s=split num evenly] [-r=split num rnd] [-o=out file] [-c=compare file] [-h=use heuristic] [-a=approx its] [-q=use stream reach]" << endl;
    cout << "Modes:" << endl;
    cout << duration_no_approx << "\t duration, no approximation" << endl;
    cout << duration_topk << "\t duration, top k" << endl;
    cout << duration_baseline << "\t duration, no approximation, stream" << endl;
    cout << duration_sampling << "\t duration, sampling" << endl;
    cout << duration_streamjump << "\t duration, stream jump" << endl;
    cout << endl;
    cout << reachability_approx << "\t reachability approximation" << endl;
    cout << static_closeness << "\t static closeness " << endl;
    cout << degree_centrality << "\t degree centrality " << endl;
    cout << degree_distribution << "\t degree distribution " << endl;
    cout << times_distribution << "\t times distribution" << endl;
    cout << endl;
    cout << fastest_path << "\t fastest path" << endl;
    cout << fastest_path_highdegree << "\t fastest path high degree" << endl;
    cout << reachability_test << "\t reachability approx temporalvsstatic" << endl;
    cout << reachability_time_test << "\t reachability times heap vs bfs vs stream" << endl;
    cout << case_study << "\t run case study experiment" << endl;
    cout << endl;
    cout << compare_results_eps << "\t compare epsilon" << endl;
    cout << compare_results_cover << "\t compare jaccard" << endl;
    cout << tg_statistics << "\t temporal graph statistics" << endl;
    cout << stats_to_file << "\t temporal graph stats_to_file" << endl;
    exit(0);
}



bool Params::parseArgs(vector<string> args) {
    if (args.size() < 2) {
        return false;
    }
    for (auto & arg : args) {
        SGLog::log() << arg << " ";
    }
    SGLog::log() << endl;

    try {
        dataset_path = args[0];
        mode = stoi(args[1]);
//        k = stoi(args[2]);
    } catch (...) {
        return false;
    }

//    approx_it = 0;
    interval_size = 1;
    nids_filename = "";

    for (size_t i = 2; i < args.size(); ++i) {
        string next = args[i];
        if (next.length() < 4) return false;
        if (next.substr(0, 3) == "-a=") {
            string valstr = next.substr(3);
            approx_it = stoi(valstr);
            SGLog::log() << "set approx iterations " << approx_it << endl;
        } else if (next.substr(0, 3) == "-i=") {
            string valstr = next.substr(3);
            interval_size = stod(valstr);
            SGLog::log() << "set interval size " << interval_size << endl;
        } else if (next.substr(0, 3) == "-h=") {
            string valstr = next.substr(3);
            use_heuristic = stoi(valstr);
            SGLog::log() << "set use heuristic " << use_heuristic << endl;
        } else if (next.substr(0, 4) == "-hl=") {
            string valstr = next.substr(4);
            heuristic_num_label = stoi(valstr);
            SGLog::log() << "set use heuristic_num_label " << heuristic_num_label << endl;
        } else if (next.substr(0, 4) == "-un=") {
            string valstr = next.substr(4);
            unit = stoi(valstr) == 0;
            SGLog::log() << "set unit " << unit << endl;
        } else if (next.substr(0, 4) == "-rg=") {
            string valstr = next.substr(4);
            reverse_graph = stoi(valstr) == 1;
            SGLog::log() << "set reverse_graph " << reverse_graph << endl;
        } else if (next.substr(0, 4) == "-rs=") {
            string valstr = next.substr(4);
            use_reachability_sort = stoi(valstr);
            SGLog::log() << "set use_reachability_sort " << use_reachability_sort << endl;
        } else if (next.substr(0, 3) == "-q=") {
            string valstr = next.substr(3);
            reachability_mode = stoi(valstr);
            SGLog::log() << "set reachability mode " << reachability_mode << endl;
        } else if (next.substr(0, 3) == "-y=") {
            string valstr = next.substr(3);
            random_seed = stoi(valstr);
            SGLog::log() << "set random seed " << random_seed << endl;
        } else if (next.substr(0, 3) == "-k=") {
            string valstr = next.substr(3);
            k = stoul(valstr);
            SGLog::log() << "set k " << k << endl;
        } else if (next.substr(0, 3) == "-w=") {
            string valstr = next.substr(3);
            repetitions = stoul(valstr);
            SGLog::log() << "set repetitions " << repetitions << endl;
        } else if (next.substr(0, 3) == "-kf=") {
            string valstr = next.substr(3);
            kf = stod(valstr);
            SGLog::log() << "set k factor " << kf << endl;
        } else if (next.substr(0, 3) == "-p=") {
            string valstr = next.substr(3);
            sampling_size = stod(valstr);
            SGLog::log() << "set sampling size " << sampling_size << endl;
        } else if (next.substr(0, 3) == "-f=") {
            string valstr = next.substr(3);
            nids_filename = valstr;
            SGLog::log() << "set nids filename " << nids_filename << endl;
        } else if (next.substr(0, 3) == "-o=") {
            string valstr = next.substr(3);
            result_filename = valstr;
            SGLog::log() << "set result filename " << result_filename << endl;
        } else if (next.substr(0, 3) == "-c=") {
            string valstr = next.substr(3);
            cmp_filename = valstr;
            SGLog::log() << "set cmp result filename " << cmp_filename << endl;
        } else if (next.substr(0, 3) == "-s=") {
            string valstr = next.substr(3);
            interval_split = stoi(valstr);
            SGLog::log() << "set interval split " << interval_split << endl;
        } else if (next.substr(0, 3) == "-r=") {
            string valstr = next.substr(3);
            interval_rnd_num = stoi(valstr);
            SGLog::log() << "set interval rnd num " << interval_rnd_num << endl;
        } else if (next.substr(0, 4) == "-ss=") {
            string valstr = next.substr(4);
            cs_steps = stoi(valstr);
            SGLog::log() << "set cs_steps " << cs_steps << endl;
        } else if (next.substr(0, 4) == "-sd=") {
            string valstr = next.substr(4);
            cs_div = stoi(valstr);
            SGLog::log() << "set cs_div " << cs_div << endl;
        } else if (next.substr(0, 4) == "-sa=") {
            string valstr = next.substr(4);
            cs_div = stoi(valstr);
            SGLog::log() << "set cs_div " << cs_div << endl;
        } else if (next.substr(0, 3) == "-u=") {
            string valstr = next.substr(3);
            directed = stoi(valstr) == 0;
            SGLog::log() << "set directed " << directed << endl;
        } else {
            return false;
        }
    }
    return true;
}

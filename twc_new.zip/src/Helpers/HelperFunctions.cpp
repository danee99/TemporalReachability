#include "HelperFunctions.h"

std::ostream& operator<<(std::ostream& os, const TGStats& tgStats) {
    os << "\n# nodes: " << tgStats.num_nodes << std::endl;
    os << "# edges: " << tgStats.num_edges << std::endl;
    os << "max out-deg: " << tgStats.max_outdegree << std::endl;
    os << "max in-deg: " << tgStats.max_indegree << std::endl;
    os << "# times: " << tgStats.num_times << std::endl;
    os << "# static edges: " << tgStats.num_static_edges << std::endl;
    os << std::endl;

    os << "avg deg: " << tgStats.avg_deg << std::endl;
    os << "avg starting times: " << tgStats.avg_starting_times << std::endl;
    os << "avg arrival times: " << tgStats.avg_arrival_times << std::endl;
    os << std::endl;

    os << "#max starting times: " << tgStats.max_num_starting_times << std::endl;
    os << "#max arrival times:  " << tgStats.max_num_arrival_times << std::endl;
    os << std::endl;

    os << tgStats.num_nodes << " & " << tgStats.num_edges << " & " << tgStats.num_times << " & " << tgStats.max_num_arrival_times << " & " << tgStats.max_num_starting_times << " & " << tgStats.max_indegree << " & " << tgStats.max_outdegree << " & " << tgStats.num_static_edges << " \\\\\n";



//    double temp_density = (double)tgStats.num_edges / (double)(tgStats.num_nodes * (tgStats.num_nodes - 1) * tgStats.num_times);
//    double density = (double)tgStats.num_edges / (double)(tgStats.num_nodes * (tgStats.num_nodes - 1) ); //* tgStats.num_times
//    os << "temporal density: " << temp_density << std::endl;
//    os << "density: " << density << std::endl;
//    os << "avg deg: " << tgStats.avg_deg << std::endl;
//    os << "min time: " << tgStats.min_time << std::endl;
//    os << "max time: " << tgStats.max_time << std::endl;
//    os << "sparsity: " << (double)tgStats.num_edges / ((double) tgStats.num_nodes * (double)tgStats.num_times) << std::endl;
//    os << "sparsity: " << (double)tgStats.num_edges / ((double) tgStats.num_nodes) << std::endl;
//    os << std::endl;
    return os;
}

namespace HF {

    std::vector<std::string> split_string(const std::string& s, char delim) {
        std::vector<std::string> result;
        std::stringstream ss(s);
        while (ss.good()) {
            std::string substr;
            getline(ss, substr, delim);
            result.push_back(substr);
        }
        return result;
    }

    TGStats getTemporalGraphStreamsStatistics(TemporalGraphStream &tgs) {

        TGStats tgStats;

        tgStats.num_edges = tgs.edges.size();
        tgStats.num_nodes = tgs.num_nodes;

        if (tgStats.num_edges == 0 || tgStats.num_nodes == 0) {
            std::cout << "num_edges or num_nodes 0" << std::endl;
            return tgStats;
        }

        std::unordered_set<Time> times;
        for (TemporalEdge &e : tgs.edges) {
            times.insert(e.t);
        }

        tgStats.num_times = times.size();

        TemporalGraph tg = tgs.toTemporalGraph();
        std::vector<unsigned long> degrees;

        tgStats.min_time = tgs.edges.begin()->t;
        tgStats.max_time = (tgs.edges.back().t + tgs.edges.back().traversal_time);

        tgStats.num_static_edges = tgs.reduce().size();

        std::vector<unsigned long> outdegree(tgs.num_nodes, 0);
        std::vector<unsigned long> indegree(tgs.num_nodes, 0);

        std::vector<std::unordered_set<Time>> starting_times(tgs.num_nodes, std::unordered_set<Time>());

        std::vector<std::unordered_set<Time>> arrival_times(tgs.num_nodes, std::unordered_set<Time>());

        for (auto &e : tgs.edges) {

            starting_times.at(e.u_id).insert(e.t);
            arrival_times.at(e.v_id).insert(e.t + e.traversal_time);

            outdegree.at(e.u_id)++;
            indegree.at(e.v_id)++;
            if (outdegree.at(e.u_id) > tgStats.max_outdegree) tgStats.max_outdegree = outdegree.at(e.u_id);
            if (indegree.at(e.v_id) > tgStats.max_indegree) tgStats.max_indegree = indegree.at(e.v_id);
        }
        for (unsigned long nid = 0; nid < tgs.num_nodes; ++nid) {
            tgStats.avg_deg += (double)(indegree.at(nid) + outdegree.at(nid));

            tgStats.avg_indeg += indegree.at(nid);
            tgStats.avg_outdeg += outdegree.at(nid);

            tgStats.avg_starting_times += starting_times.at(nid).size();

            if (tgStats.max_num_arrival_times < arrival_times.at(nid).size()) tgStats.max_num_arrival_times = arrival_times.at(nid).size();
            if (tgStats.max_num_starting_times < starting_times.at(nid).size()) tgStats.max_num_starting_times = starting_times.at(nid).size();
            tgStats.avg_arrival_times += arrival_times.at(nid).size();
        }
        tgStats.avg_deg /= (double)tgs.num_nodes;
        tgStats.avg_indeg /= (double)tgs.num_nodes;
        tgStats.avg_outdeg /= (double)tgs.num_nodes;
        tgStats.avg_starting_times /= (double)tgs.num_nodes;
        tgStats.avg_arrival_times /= (double)tgs.num_nodes;

        return tgStats;

    }

    void writeStatisticsToFile(TemporalGraphStream &tgs, std::string const &filename) {
        std::unordered_set<Time> times;
        for (TemporalEdge &e : tgs.edges) {
            times.insert(e.t);
        }

        TemporalGraph tg = tgs.toTemporalGraph();
        std::vector<unsigned long> degrees;

        std::vector<unsigned long> outdegree(tgs.num_nodes, 0);
        std::vector<unsigned long> indegree(tgs.num_nodes, 0);
        std::vector<std::unordered_set<Time>> starting_times(tgs.num_nodes, std::unordered_set<Time>());
        std::vector<std::unordered_set<Time>> arrival_times(tgs.num_nodes, std::unordered_set<Time>());

        for (auto &e : tgs.edges) {
            starting_times.at(e.u_id).insert(e.t);
            arrival_times.at(e.v_id).insert(e.t + e.traversal_time);
            outdegree.at(e.u_id)++;
            indegree.at(e.v_id)++;
        }
        std::vector<std::string> lines;
        lines.emplace_back("starting_times arrival_times outdegree indegree");
        for (int i = 0; i < tgs.num_nodes; ++i) {
            std::string line = std::to_string(indegree[i]) + " " + std::to_string(outdegree[i])
                    + " " + std::to_string(arrival_times[i].size()) + " " + std::to_string(starting_times[i].size());
            lines.push_back(line);
        }

        writeVectorToFile(filename, lines);
    }

}
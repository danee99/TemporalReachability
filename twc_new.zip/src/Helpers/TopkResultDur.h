#ifndef CENTRALITY_TOPKRESULTxx_H
#define CENTRALITY_TOPKRESULTxx_H

#include <set>
#include <memory>
#include "TemporalGraph/TemporalGraphs.h"

struct comp1
{
    template<typename T>
    bool operator()(const T& l, const T& r) const {
        return l > r;
    }
};

class TopkResultDur {

public:

    explicit TopkResultDur(const unsigned int k) :
        k(k), minMaxTopK(MAX_UINT_VALUE) {
    };

    void insert(Time closeness);

    bool doApproximation() {
        return topk.size() >= k;
    }

    Time getMinMaxTopk() {
        return minMaxTopK;
    }

private:

    unsigned int k{};

    Time minMaxTopK{};

    std::set<Time, comp1> topk{};

};


#endif //CENTRALITY_TOPKRESULT_H

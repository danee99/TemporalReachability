#ifndef CENTRALITY_HELPERFUNCTIONS_H
#define CENTRALITY_HELPERFUNCTIONS_H

#include "Paths/LabelPQ.h"
#include <list>
#include <set>
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <numeric>


struct TGStats {
    unsigned long num_nodes = 0;
    unsigned long num_edges = 0;
    unsigned long num_static_edges = 0;
    unsigned long num_times = 0;
    double avg_deg = 0;
    double avg_indeg = 0;
    double avg_outdeg = 0;
    unsigned long max_indegree = 0;
    unsigned long max_outdegree = 0;
//    unsigned long max_starting_times = 0;
//    unsigned long min_starting_times = MAX_UINT_VALUE;
    unsigned long max_num_starting_times = 0;
    unsigned long max_num_arrival_times = 0;
    double avg_starting_times = 0;
    double avg_arrival_times = 0;
    Time min_time;
    Time max_time;
};

std::ostream& operator<<(std::ostream& os, const TGStats& ts);

namespace HF {

    TGStats getTemporalGraphStreamsStatistics(TemporalGraphStream &tgs);


    template<typename T>
    void get_mean_std(std::vector<T> &values, double &mean, double &stdev) {
        double sum = std::accumulate(std::begin(values), std::end(values), 0.0);
        mean = sum / values.size();
        double accum = 0.0;
        std::for_each (std::begin(values), std::end(values), [&](const double d) {
            accum += (d - mean) * (d - mean);
        });
        stdev = sqrt(accum / (values.size()));
    }


    template<typename T>
    void writeVectorToFile(const std::string &filename, std::vector<T> data) {
        std::ofstream fs;
        fs.open(filename);
        if (!fs.is_open()) {
            std::cout << "Could not write data to " << filename << std::endl;
            return;
        }
        fs << std::setprecision(50);
        for (auto &d : data)
            fs << d << std::endl;

        fs.close();
    }

    template<typename T, typename R>
    void writeVectorToFile(const std::string &filename, std::vector<std::pair<T, R>> data, const std::string &sep) {
        std::ofstream fs;
        fs.open(filename);
        if (!fs.is_open()) {
            std::cout << "Could not write data to " << filename << std::endl;
            return;
        }
        fs << std::setprecision(50);
        for (auto &d : data)
            fs << d.first << sep << d.second << std::endl;

        fs.close();
    }

    std::vector<std::string> split_string(const std::string &s, char delim);

    void writeStatisticsToFile(TemporalGraphStream &tgs, std::string const &filename);

}
#endif //CENTRALITY_HELPERFUNCTIONS_H

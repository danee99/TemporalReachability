#ifndef CENTRALITY_TOPKRESULT_H
#define CENTRALITY_TOPKRESULT_H

#include "TemporalGraph/TemporalGraphs.h"
#include <set>
#include <memory>

struct comp
{
    template<typename T>
    bool operator()(const T& l, const T& r) const {
        return l.closeness > r.closeness;
    }
};

struct TopKEntry {

    TopKEntry(double closeness, NodeId nid) : closeness(closeness) {
        nids.push_back(nid);
    };

    ~TopKEntry() = default;

    double closeness = 0;
    std::vector<NodeId> nids;
};

class TopkResult {

public:

    TopkResult() = default;

    explicit TopkResult(const unsigned int k, const unsigned int num_nodes) :
        k(k), num_nodes(num_nodes), minMaxTopK(MAX_UINT_VALUE), h(num_nodes) {
    };

    explicit TopkResult(const unsigned int k, const unsigned int num_nodes, const unsigned int h) :
            k(k), num_nodes(num_nodes), minMaxTopK(MAX_UINT_VALUE), h(h) {};

    void insert(double closeness, NodeId nid);

    void print();

    double getMinMaxTopk() {
        return minMaxTopK;
    }

    bool doApproximation() {
        return topk.size() >= k;
    }

    std::set<TopKEntry, comp> getSet() {
        return topk;
    }

    std::string countTopkSet(TopkResult &result);

    void printAllNids(const std::string& file);

    std::vector<std::pair<NodeId, double>> getResults();

    auto getAllNids() {
        std::vector<NodeId> allnids;
        for (auto &e : topk) {
            for (auto &n : e.nids) {
                allnids.push_back(n);
            }
        }
        return allnids;
    }

private:

    unsigned int k{};

    unsigned int num_nodes{}, h{};

    double minMaxTopK{};

    std::set<TopKEntry, comp> topk;

    std::vector<NodeId> allnids;

    std::string getResultString();
};

struct Result {
    Result(double running_time, std::pair<Time, Time> interval, TopkResult topkResult) :
            resultstr(std::to_string(running_time) + " s"), interval(std::move(interval)), topkResult(std::move(topkResult)) {}

    Result(std::string resultstr, std::pair<Time, Time> interval, TopkResult topkResult) :
            resultstr(std::move(resultstr)), interval(std::move(interval)), topkResult(std::move(topkResult)) {}

    explicit Result(std::string str) : resultstr(std::move(str)) { }

    std::string resultstr;
    std::pair<Time, Time> interval;
    TopkResult topkResult;

    std::vector<std::pair<NodeId, double>> all_results;
};

#endif //CENTRALITY_TOPKRESULT_H

#ifndef CENTRALITY_PARAMS_H
#define CENTRALITY_PARAMS_H

#include <utility>
#include <string>
#include <vector>
#include <TemporalGraph/TemporalGraphs.h>

enum MODES {
    duration_no_approx,
    duration_topk,
    duration_baseline,
    duration_sampling,
    reachability_approx,
    closeness_cover_sampling,
    static_closeness,
    degree_centrality,
    degree_distribution,
    times_distribution,
    fastest_path,
    fastest_path_highdegree,
    compare_results_eps,
    compare_results_cover,
    reachability_test,
    reachability_time_test,
    case_study,
    case_study2,
    tg_statistics,
    test,
    rev_duration_no_approx,
    duration_streamjump,
    stats_to_file

};


void show_help();

struct Params {
    std::string dataset_path;
    unsigned int mode = 0;
    unsigned int k = 0;
    unsigned int repetitions = 0;
    double kf = 0;
    unsigned int approx_it = 0;
    unsigned int reachability_mode = 0;
    unsigned int random_seed = 0;
    double interval_size = 1;
    double sampling_size = 1.0;
    std::string nids_filename;
    std::string result_filename;
    std::string cmp_filename;
    unsigned int use_heuristic = 0;
    unsigned int heuristic_num_label = 2;
    bool unit = true;
    int use_reachability_sort = 0;
    bool reverse_graph = false;

    unsigned int cs_steps = 100; // for case study
    unsigned int cs_div = 10; // for case study

    unsigned int interval_split = 0;
    unsigned int interval_rnd_num = 0;

    bool directed = true;

    bool parseArgs(std::vector<std::string> args);
};


#endif //CENTRALITY_PARAMS_H

#include <fstream>
#include <iomanip>
#include <numeric>
#include <cmath>
#include "ResultFile.h"
#include "Helpers/HelperFunctions.h"
#include "SGLog.h"
#include "Helpers/TopkResult.h"

using namespace std;

void ResultFile::save() {
    std::ofstream out(datasetname);
    out << std::setprecision(100);
    sort(results.begin(), results.end(), [](auto &l, auto &r) {return l.first < r.first;});
    for (auto &r : results) {
        out << r.second << endl;
    }
    cout << "Saved to " << datasetname << endl;
    out.close();
}

bool ResultFile::load() {
    ifstream fs;
    fs.open(datasetname);
    if (!fs.is_open()) {
        cout << "Error loading " << datasetname << endl;
        return false;
    }
    string line;
    while (getline(fs, line)) {
        auto token = HF::split_string(line, ',');
        results.emplace_back(stoul(token.at(0)), stod(token.at(1)));
    }
    fs.close();
    return true;
}

bool ResultFile::loadReach() {
    ifstream fs;
    fs.open(datasetname);
    if (!fs.is_open()) {
        cout << "Error loading " << datasetname << endl;
        return false;
    }
    string line;
    getline(fs, line);
    NodeId nid = 0;
    while (getline(fs, line)) {
        auto token = stod(line);
        results.emplace_back(nid++, token);
    }
    fs.close();
    return true;
}

Result ResultFile::compare(vector<std::pair<NodeId, double>> &results2, unsigned int k) {

    double diff = 0.0;
    double relative_diff = 0.0;
    if (k == 0) k = results2.size();
    vector<double> rds;
    double sum_e = 0;
    double sum_r = 0;
//    sort(results2.begin(), results2.end(), [](const auto &a, const auto &b){return a.second > b.second;});
    sort(results.begin(), results.end(), [](const auto &a, const auto &b){return a.first < b.first;});
    sort(results2.begin(), results2.end(), [](const auto &a, const auto &b){return a.first < b.first;});
    for (size_t i = 0; i < k; ++i) {
        auto r = results[i];
        auto e = results2[i];
        cout << r.first << " " << r.second << "\t" << e.first << " " << e.second << endl;

        auto nr = r.second;
        auto ne = e.second;

        sum_e += ne;
        sum_r += nr;

        assert(e.first == r.first);

        double d;
        double rd = 0;
        if (ne < nr){
            d = (nr - ne);
            if (nr > 0)
                rd = (d / nr);
        } else {
            d = (ne - nr);
            if (ne > 0)
                rd = (d / ne);
        }

        diff += d;
        relative_diff += rd;
        rds.push_back(rd);
    }

    diff /= k;
    relative_diff /= k;

    double sum = std::accumulate(std::begin(rds), std::end(rds), 0.0);
    double m =  sum / rds.size();

    double accum = 0.0;
    std::for_each (std::begin(rds), std::end(rds), [&](const double d) {
        accum += (d - m) * (d - m);
    });

    double stdev = sqrt(accum / (rds.size()));

    SGLog::log() << "k: " << k << endl;
    SGLog::log() << "Average epsilon: " << diff << endl;
    auto str = "Average relative epsilon: " + to_string(relative_diff);
    str.append("\nStandard deviation: ").append(to_string(stdev));
    SGLog::log() << str << endl;
    SGLog::log() << "Ratio: " << sum_r/sum_e << endl;
    str.append("\nRatio: ").append(to_string(sum_r/sum_e));
    Result result(str);
    return result;
}

Result ResultFile::compareCover(vector<std::pair<NodeId, double>> &results2, unsigned int k) {
    TopkResult t2(k, results2.size());
    for (auto &pair : results2) {
        t2.insert(pair.second, pair.first);
    }
    TopkResult topkResult(k, results.size());
    for (auto &pair : results) {
        topkResult.insert(pair.second, pair.first);
    }
    auto str = t2.countTopkSet(topkResult);
    Result result(str);
    return result;
}

#ifndef CENTRALITY_STATICCLOSENESS_H
#define CENTRALITY_STATICCLOSENESS_H

#include <Helpers/TopkResult.h>
#include "TemporalGraph/TemporalGraphs.h"

class StaticCloseness {

public:

    static Result calculateCloseness(TemporalGraph &tg, unsigned int k, unsigned int interval_start, unsigned int interval_end, const std::string& nidsFilename = "");

};


#endif //CENTRALITY_STATICCLOSENESS_H

#include "StaticCloseness.h"
#include "Paths/LabelPQ.h"
#include "Helpers/TopkResult.h"
#include "Helpers/SGLog.h"

using namespace std;


Result StaticCloseness::calculateCloseness(TemporalGraph &tg, unsigned int const k, unsigned int interval_start, unsigned int interval_end, const string& nidsFilename) {

    TopkResult topkResult(k, tg.num_nodes);

    SGLog::log() << "calculation static closeness." << endl;
    auto start = std::chrono::high_resolution_clock::now();

    vector<pair<NodeId, double>> result;

#pragma omp parallel for default(none) shared(tg, topkResult, interval_start, interval_end, result)
    for (NodeId nid = 0; nid < tg.num_nodes; ++nid) {
        vector<shared_ptr<label>> nodelabels(tg.nodes.size(), nullptr);
        auto l = std::make_shared<label>();
        l->nid = nid;

        nodelabels.at(nid) = l;

        list<shared_ptr<label>> q;

        q.push_back(l);

        vector<bool> visited(tg.nodes.size(), false);

        std::vector<unsigned int> d(tg.num_nodes, 0);

        while (!q.empty()) {

            auto cur = q.front();
            q.pop_front();

            if (visited.at(cur->nid)) continue;

            visited.at(cur->nid) = true;


            for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {

                if (visited.at(e.v_id)) continue;

                if (e.t < interval_start || e.t + 1 > interval_end) continue;

                if (nodelabels.at(e.v_id) == nullptr) {
                    auto lnew = std::make_shared<label>();

                    lnew->nid = e.v_id;
                    d.at(e.v_id) = d.at(e.u_id) + 1;

                    nodelabels.at(e.v_id) = lnew;

                    q.push_back(lnew);

                }
            }
        }

        double closeness = 0.0;
        for (NodeId v = 0; v < tg.nodes.size(); ++v) {
            if (d.at(v) > 0) {
                closeness += 1.0 / d.at(v);
            }
        }
#pragma omp critical
        {
        topkResult.insert(closeness, nid);
        result.emplace_back(nid, closeness);
        }
    }
    auto finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = finish - start;

    topkResult.print();
    SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";

    if (nidsFilename.length() > 0)
        topkResult.printAllNids(nidsFilename);

    Result rresult(elapsed.count(), {interval_start, interval_end}, topkResult);
    rresult.all_results = topkResult.getResults();
    return rresult;
}


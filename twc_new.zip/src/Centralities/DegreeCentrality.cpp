#include <unordered_map>
#include <cassert>
#include "DegreeCentrality.h"
#include "Helpers/TopkResult.h"
#include "Helpers/HelperFunctions.h"
#include "Helpers/SGLog.h"

using namespace std;

Result DegreeCentrality::calculateDegreeCentrality(TemporalGraph &tg, unsigned int k, const std::string &nidsFilename) {

    TopkResult topkResult(k, tg.num_nodes);

    std::vector<std::pair<NodeId, double>> perm;

    SGLog::log() << "calculation degree centrality." << endl;

//    std::vector<std::pair<NodeId, double>> results;
    auto start = std::chrono::high_resolution_clock::now();

    for (TGNode &n : tg.nodes) {
        perm.emplace_back(n.id, n.adjlist.size());
    }
    auto unsorted = perm;
    std::stable_sort(perm.begin(), perm.end(), [](const pair<NodeId, unsigned int> & a, const pair<NodeId, unsigned int> & b) -> bool {
        return a.second > b.second;
    });

    for (auto &p : perm) {
        topkResult.insert(p.second, p.first);
    }

    auto finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = finish - start;
    SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";

    topkResult.print();

    if (nidsFilename.length() != 0)
        topkResult.printAllNids(nidsFilename);

    Result result(elapsed.count(), {0, 1}, topkResult);
    result.all_results = unsorted;
    return result;
}

void DegreeCentrality::calculateDegreeDistribution(TemporalGraph &tg, unsigned int k, const string &filename) {

    vector<unsigned int> degs;
    for (auto &n : tg.nodes) {
        degs.push_back(n.adjlist.size());
    }

    unordered_map<unsigned int, unsigned int> histogram;

    for (auto &d : degs) {
        auto h = histogram.find(d);
        if (h == histogram.end()) {
            histogram.insert({d, 1});
        } else {
            ++histogram.at(d);
        }
    }

    vector<pair<unsigned int, unsigned int>> ps;
    for (auto &h : histogram)
        ps.emplace_back(h);

    std::stable_sort(ps.begin(), ps.end(), [](const pair<unsigned int, unsigned int> & a, const pair<unsigned int, unsigned int> & b) -> bool {
        return a.first < b.first;
    });

    auto total = 0;
    for (auto &h : ps) {
        cout << h.first << " " << h.second << endl;
        total += h.first * h.second;
    }

    assert(total == tg.num_edges);

    HF::writeVectorToFile(filename, ps, ", ");
}

void DegreeCentrality::calculateTimesDistribution(TemporalGraph &tg, unsigned int k, const string &filename) {

    vector<unsigned int> times;
    for (auto &n : tg.nodes) {
        for (auto &e : n.adjlist)
            times.push_back(e.t / k);
    }

    unordered_map<unsigned int, unsigned int> histogram;

    for (auto &d : times) {
        auto h = histogram.find(d);
        if (h == histogram.end()) {
            histogram.insert({d, 1});
        } else {
            ++histogram.at(d);
        }
    }

    vector<pair<unsigned int, unsigned int>> ps;
    for (auto &h : histogram)
        ps.emplace_back(h);

    std::stable_sort(ps.begin(), ps.end(), [](const pair<unsigned int, unsigned int> & a, const pair<unsigned int, unsigned int> & b) -> bool {
        return a.first < b.first;
    });

    auto total = 0;
    for (auto &h : ps) {
        cout << h.first << " " << h.second << endl;
        total += h.first * h.second;
    }

    HF::writeVectorToFile(filename, ps, ", ");
}



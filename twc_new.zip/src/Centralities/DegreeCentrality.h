#ifndef CENTRALITY_DEGREECENTRALITY_H
#define CENTRALITY_DEGREECENTRALITY_H

#include <Helpers/TopkResult.h>
#include "TemporalGraph/TemporalGraphs.h"

class DegreeCentrality {

public:

    Result calculateDegreeCentrality(TemporalGraph &tg, unsigned int k, const std::string& nidsFilename = "");

    void calculateDegreeDistribution(TemporalGraph &tg, unsigned int k, const std::string& filename = "");

    void calculateTimesDistribution(TemporalGraph &tg, unsigned int k, const std::string& filename = "");

};


#endif //CENTRALITY_DEGREECENTRALITY_H

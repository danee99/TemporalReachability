#ifndef CENTRALITY_REACHABILITYEVALUATION_H
#define CENTRALITY_REACHABILITYEVALUATION_H


void reachability_approx_test(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params);

void reachability_running_time_test(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params);

#endif //CENTRALITY_REACHABILITYEVALUATION_H

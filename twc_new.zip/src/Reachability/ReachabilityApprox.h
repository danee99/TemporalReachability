//
// Created by lutz on 09.12.19.
//

#ifndef CENTRALITY_REACHABILITYAPPROX_H
#define CENTRALITY_REACHABILITYAPPROX_H

#include "TemporalGraph/TemporalGraphs.h"
#include <unordered_set>
#include <memory>
#include <list>
#include <unordered_map>

struct TGE;

struct TGN {
    TGN() = default;
    NodeId id = 0;
    Time maxTime = 0;
    std::list<std::shared_ptr<TGE>> adjlist;
};

struct TGE {
    TGE() = default;
    TGE(const TGE& tge) {
        u = std::make_shared<TGN>(*tge.u);
        v = std::make_shared<TGN>(*tge.v);
        t = tge.t;
    }
    std::shared_ptr<TGN> u;
    std::shared_ptr<TGN> v;
    Time t = 0;
};

class ReachabilityApprox {

public:

    void approxReachability(TemporalGraph &tg, std::vector<unsigned int> &r, unsigned int iterations, Time interval_start, Time interval_end);
    void approxReachability2(TemporalGraph &tg, std::vector<unsigned int> &r, unsigned int iterations, Time interval_start, Time interval_end);

    static void approxReachabilityStream(TemporalGraphStream &tgs, std::vector<unsigned int> &r, unsigned int iterations, Time interval_start, Time interval_end);

private:

    static void getR(unsigned int num_nodes, unsigned int size, std::vector<std::vector<std::pair<NodeId, double>>> &Rs);

};


#endif //CENTRALITY_REACHABILITYAPPROX_H

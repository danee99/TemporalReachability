#include "ReachabilityApprox.h"
#include "Paths/LabelPQ.h"
#include <random>
#include <list>
#include <queue>
#include <chrono>
#include <algorithm>
#include <Helpers/SGLog.h>

using namespace std;

int g_seed = 428924984;

inline int fastrand() {
    g_seed = (214013*g_seed+2531011);
    return (g_seed>>16)&0x7FFF;
}

void ReachabilityApprox::getR(unsigned int const num_nodes, unsigned int size, vector<vector<pair<NodeId, double>>> &Rs) {
    std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());
    std::uniform_real_distribution<double> distribution(0, 1.0);

    for (size_t iter = 0; iter < size; ++iter) {
        vector<pair<NodeId, double>> R(num_nodes);
        for (size_t i = 0; i < num_nodes; ++i) {
//            R[i] = {i, 1.0*fastrand()/(double) INT32_MAX};
            R[i] = {i, 1-(distribution(generator))};
        }
        Rs.push_back(R);
    }
}

struct TGNode2 {
    uint id = 0;
    std::list<TemporalEdge> adjlist;
    Time maxTime = 0;
    bool done = false;

    void addEdge(const TemporalEdge& e) {
        adjlist.push_back(e);
        if (e.t > maxTime) maxTime = e.t;
    }

};



using TGNodes2 = std::vector<TGNode2>;

struct TemporalGraph2 {
    TGNodes2 nodes{};
    unsigned int num_nodes{};
    unsigned int num_edges{};
};

TemporalGraph2 toReverseTemporalGraph2(TemporalGraph &tg, Time interval_end) {
    TemporalGraph2 rtg;
    TemporalEdges tes;
    Time maxT = 0;
    for (TGNode const &n : tg.nodes) {
        TGNode2 nnew;
        nnew.id = n.id;
        for (TemporalEdge const &e : n.adjlist) {
            TemporalEdge x;
            x.v_id = e.u_id;
            x.u_id = e.v_id;
            x.t = 1 + interval_end - e.t;
//            x.t = 1 + max_time - e.t;
            x.traversal_time = 1;
            x.id = e.id;
            tes.push_back(x);
            rtg.num_edges++;
            if (x.t > maxT)
                maxT = x.t;
        }
        rtg.nodes.push_back(nnew);
        ++rtg.num_nodes;
    }
    for (auto &e : tes) {
        rtg.nodes.at(e.u_id).addEdge(e);
    }
    rtg.num_nodes = tg.num_nodes;
    return rtg;
}


void ReachabilityApprox::approxReachability(TemporalGraph &tg, std::vector<unsigned int> &r, unsigned int const iterations, Time interval_start, Time interval_end) {
    // calculate the temporal reverse graph
    TemporalGraph rtg = tg.toReverseTemporalGraph(interval_start, interval_end);

    vector<double> res(rtg.num_nodes, 0);
    std::vector<std::vector<std::pair<NodeId, double>>> Rs;
    getR(rtg.num_nodes, iterations, Rs);

//#pragma omp parallel for default(none) shared(res, Rs, rtg,iterations)
    for (size_t i = 0; i < iterations; ++i) {
        vector<pair<NodeId, double>> R = Rs.at(i);

        std::sort(R.begin(), R.end(), [](const auto & a, const auto & b) -> bool {
            return a.second < b.second;
        });

//        cout << R.begin()->first << " " << R.begin()->second << endl;

        // get LE
        auto tg = rtg;
        vector<double> le(tg.num_nodes);
        vector<bool> foundV(tg.num_nodes, false);

        for (auto &p : R) {
//        for (int x = 0; x <= 1000; ++x) {
//            auto &p = R.at(rand() % R.size());
            NodeId nid = p.first;
            if (foundV.at(nid)) continue;
            foundV.at(nid) = true;
            tg.nodes.at(nid).done = true;

            le.at(nid) = p.second;

            vector<TGNode*> result;// = getReachableNodes(tg, nid/*, foundV*/);
            vector<shared_ptr<label>> nodelabels(tg.nodes.size(), nullptr);
            auto l = make_shared<label>();
            l->a = 0;
            l->nid = nid;

            nodelabels.at(nid) = l;

            LabelPQASP q;

            q.push(l);
//            vector<TGNode*> result;
            vector<Time> arrivalTime(tg.num_nodes, 0);

            vector<bool> inQ(tg.nodes.size(), false);
            inQ.at(nid) = true;

            vector<bool> visited(tg.nodes.size(), false);

            while (!q.empty()) {
                auto cur = q.top();
                q.pop();

                inQ.at(cur->nid) = false;

                if (visited.at(cur->nid)) continue;

                visited.at(cur->nid) = true;

                for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
                    if (e.deleted) continue;

                    if (visited.at(e.v_id)) continue;

                    if (e.t >= cur->a) {
                        if (nodelabels.at(e.v_id) == nullptr) {
                            auto lnew = make_shared<label>();
                            lnew->a = e.t + 1;
                            lnew->nid= e.v_id;

                            nodelabels.at(e.v_id) = lnew;
                            if (tg.nodes[lnew->nid].maxTime >= e.t + 1) {
                                q.push(lnew);
                                inQ.at(e.v_id) = true;
                            }

                            if (!tg.nodes.at(e.v_id).done)
                                result.push_back(&tg.nodes.at(e.v_id));

                            arrivalTime.at(e.v_id) = e.t + 1;
                        }
                        else {
                            if (arrivalTime.at(e.v_id) > e.t + 1) {
                                arrivalTime.at(e.v_id) = e.t + 1;
                                nodelabels.at(e.v_id)->a = e.t + 1;

                                if (tg.nodes[nodelabels.at(e.v_id)->nid].maxTime >= e.t + 1) {
                                    if (!inQ.at(e.v_id)) {
                                        q.push(nodelabels.at(e.v_id));
                                        inQ.at(e.v_id) = true;
                                    } else
                                        q.decreasedKey(nodelabels.at(e.v_id)->pq_pos);
                                }
                            }
                        }
                        e.deleted = true;
                    }
                }
            }


            for (TGNode *n : result) {
                if (foundV.at(n->id)) {
                    continue;
                }

                le.at(n->id) = p.second;
                foundV.at(n->id) = true;
                n->done = true;
            }
        }

        for (TGNode &n : rtg.nodes) {
            double est = le.at(n.id);
            res.at(n.id) += est;
        }
    }

    // estimate
//    for (TGNode &n : rtg.nodes) {
//        r.at(n.id) = max((iterations / res.at(n.id) - 1), 1.0);
//    }
//#pragma omp parallel for default(none) shared(res, r, rtg, iterations)
    for (NodeId nid = 0; nid < rtg.num_nodes; ++nid) {
        r.at(nid) = max((iterations / res.at(nid) - 1), 0.0);
    }

}

void ReachabilityApprox::approxReachability2(TemporalGraph &tg, std::vector<unsigned int> &r, unsigned int const iterations, Time interval_start, Time interval_end) {
    // calculate the temporal reverse graph
    auto rtg = toReverseTemporalGraph2(tg, interval_end);

    vector<double> res(rtg.num_nodes, 0);
    std::vector<std::vector<std::pair<NodeId, double>>> Rs;
    getR(rtg.num_nodes, iterations, Rs);

    for (size_t i = 0; i < iterations; ++i) {
        vector<pair<NodeId, double>> R = Rs.at(i);

        std::sort(R.begin(), R.end(), [](const auto & a, const auto & b) -> bool {
            return a.second < b.second;
        });

        // get LE
        auto tg = rtg;
        vector<double> le(tg.num_nodes);
        vector<bool> foundV(tg.num_nodes, false);

        for (auto &p : R) {
            NodeId nid = p.first;
            if (foundV.at(nid)) continue;
            foundV.at(nid) = true;
            tg.nodes.at(nid).done = true;

            le.at(nid) = p.second;

            vector<TGNode2*> result;
            vector<shared_ptr<label>> nodelabels(tg.nodes.size(), nullptr);
            auto l = make_shared<label>();
            l->a = 0;
            l->nid = nid;

            nodelabels.at(nid) = l;

            LabelPQASP q;

            q.push(l);
//            vector<TGNode*> result;
            vector<Time> arrivalTime(tg.num_nodes, 0);

            vector<bool> inQ(tg.nodes.size(), false);
            inQ.at(nid) = true;

            vector<bool> visited(tg.nodes.size(), false);

            while (!q.empty()) {
                auto cur = q.top();
                q.pop();

                inQ.at(cur->nid) = false;

                if (visited.at(cur->nid)) continue;

                visited.at(cur->nid) = true;

                auto &adjlist = tg.nodes[cur->nid].adjlist;
                auto it = adjlist.begin();
                while (it != adjlist.end()){
                    auto e = *(it);

                    if (visited.at(e.v_id)) {
                        it = adjlist.erase(it);
                        continue;
                    }
                    if (e.t >= cur->a) {
                        if (nodelabels.at(e.v_id) == nullptr) {
                            auto lnew = make_shared<label>();
                            lnew->a = e.t + 1;
                            lnew->nid= e.v_id;

                            nodelabels.at(e.v_id) = lnew;
                            if (tg.nodes[lnew->nid].maxTime >= e.t + 1) {
                                q.push(lnew);
                                inQ.at(e.v_id) = true;
                            }

                            if (!tg.nodes.at(e.v_id).done)
                                result.push_back(&tg.nodes.at(e.v_id));

                            arrivalTime.at(e.v_id) = e.t + 1;
                        }
                        else {
                            if (arrivalTime.at(e.v_id) > e.t + 1) {
                                arrivalTime.at(e.v_id) = e.t + 1;
                                nodelabels.at(e.v_id)->a = e.t + 1;

                                if (tg.nodes[nodelabels.at(e.v_id)->nid].maxTime >= e.t + 1) {
                                    if (!inQ.at(e.v_id)) {
                                        q.push(nodelabels.at(e.v_id));
                                        inQ.at(e.v_id) = true;
                                    } else
                                        q.decreasedKey(nodelabels.at(e.v_id)->pq_pos);
                                }
                            }
                        }
                        it = adjlist.erase(it);
                    } else {
                        ++it;
                    }
                }
            }

            for (auto *n : result) {
                if (foundV.at(n->id)) {
                    continue;
                }

                le.at(n->id) = p.second;
                foundV.at(n->id) = true;
                n->done = true;
            }
        }

        for (auto &n : rtg.nodes) {
            double est = le.at(n.id);
            res.at(n.id) += est;
        }
    }


    for (NodeId nid = 0; nid < rtg.num_nodes; ++nid) {
        r.at(nid) = max((iterations / res.at(nid) - 1), 0.0);
    }

}



// todo version with stream in which edges are deleted

struct se {
    uint u_id,v_id,t;
};

struct stg {
    vector<se> edges;
    uint num_nodes;
};

stg toReverseTemporalGraph(TemporalGraphStream &tgs, Time interval_end) {
    stg rtg;
    for (TemporalEdge const &e : tgs.edges) {
        se x{};
        x.v_id = e.u_id;
        x.u_id = e.v_id;
        x.t = 1 + interval_end - e.t;
        rtg.edges.push_back(x);
    }
    rtg.num_nodes = tgs.num_nodes;
    return rtg;
}


void ReachabilityApprox::approxReachabilityStream(TemporalGraphStream &tgs, std::vector<unsigned int> &r, unsigned int const iterations, Time interval_start, Time interval_end) {
    // calculate the temporal reverse graph
    auto rtg = toReverseTemporalGraph(tgs, interval_end);

    vector<double> res(rtg.num_nodes, 0);
    std::vector<std::vector<std::pair<NodeId, double>>> Rs;
    getR(rtg.num_nodes, iterations, Rs);
    for (size_t i = 0; i < iterations; ++i) {
        vector<pair<NodeId, double>> R = Rs.at(i);

        std::sort(R.begin(), R.end(), [](const auto & a, const auto & b) -> bool {
            return a.second < b.second;
        });

        // get LE
        auto tmptgs = rtg;
        vector<double> le(tmptgs.num_nodes);
        vector<bool> foundV(tmptgs.num_nodes, false);

        for (auto &p : R) {
            NodeId nid = p.first;
            if (foundV.at(nid)) continue;
            foundV.at(nid) = true;

            le.at(nid) = p.second;

            vector<uint> result;
            result.push_back(nid);

            vector<Time> minarr(tmptgs.num_nodes, MAX_UINT_VALUE);
            minarr[nid] = 0;

            auto it = tmptgs.edges.begin();
            while (it != tmptgs.edges.end()){
                auto e = *it;

                if (minarr[e.u_id] <= e.t) {
                    if (minarr[e.v_id] == MAX_UINT_VALUE) {
                        if (!foundV[e.v_id])
                            result.push_back(e.v_id);
                    }
                    if (minarr[e.v_id] > e.t + 1) {
                        minarr[e.v_id] = e.t + 1;
//                        it = tmptgs.edges.erase(it);
                    } else {
                        ++it;
                    }
                } else {
                    ++it;
                }
            }

            for (auto n : result) {
                if (foundV.at(n)) {
                    continue;
                }

                le.at(n) = p.second;
                foundV.at(n) = true;
            }
        }

        for (uint n=0; n < tmptgs.num_nodes; ++n) {
            double est = le.at(n);
            res.at(n) += est;
        }
    }

    for (NodeId nid = 0; nid < rtg.num_nodes; ++nid) {
        r.at(nid) = max((iterations / res.at(nid) - 1), 0.0);
    }

}
#include <Helpers/SGLog.h>
#include <Helpers/Params.h>
#include <cmath>
#include <Helpers/HelperFunctions.h>
#include "ReachabilityEvaluation.h"
#include "TemporalReachability.h"
#include "ReachabilityApprox.h"
#include <map>

using namespace std;

void saveReachabilities(const string &path, double time, vector<uint> &r) {
    string name = path + ".reach";
    std::ofstream fs;
    fs.open(name);
    fs << std::setprecision(100);
    if (!fs.is_open()) {
        std::cout << "Could not write data to " << name << std::endl;
        return;
    }
    fs << time << std::endl;
    for (auto &d : r) fs << d << std::endl;
    fs.close();
    cout << "Saved reachability to " << name << endl;
}

bool loadReachabilities(const string &path, double &elapsed1, vector<uint> &r) {
    string name = path + ".reach";
    std::ifstream fs;
    fs.open(name);
    if (!fs.is_open()) {
        SGLog::log() << "Did not load reachability file " << name << std::endl;
        return false;
    }
    std::string line;
    getline(fs, line);
    elapsed1 = stod(line);
    while (getline(fs, line)) {
        unsigned long val = stoul(line);
        r.push_back(val);
    }
    fs.close();
    SGLog::log() << "Load reachability file " << name << std::endl;
    return true;
}

TemporalGraphStream filterForReachability(TemporalGraphStream &tgs) {
    auto edges = tgs.edges;
    map<string, TemporalEdge> tes;
    for (auto &e : tgs.edges) {
        string s = to_string(e.u_id) + "-" + to_string(e.v_id);
        if (tes.find(s) == tes.end()) {
            tes[s] = e;
        } else {
            if (tes[s].t > e.t)
                tes[s] = e;
        }
    }
    for (auto &m : tes) {
        edges.push_back(m.second);
    }
    TemporalGraphStream result;
    result.num_nodes = tgs.num_nodes;
    result.edges = edges;
    result.sort_edges();
    return result;
}


void reachability_approx_test(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params) {
//    auto tgs = filterForReachability(xtgs);
//    auto tg = tgs.toTemporalGraph();
    Time interval_start = tgs.edges[0].t;
    Time interval_end = tgs.edges.back().t + tgs.edges.back().traversal_time;
    Timer timer;

    vector<uint> r_exact;
    TemporalReachability tgreach;
    double reachtime;
    auto reach_loaded = loadReachabilities(params.dataset_path, reachtime, r_exact);
    SGLog::log() << "Calculating reachability exactly..." << flush;
    if (!reach_loaded) {
        timer.start();
//        tgreach.initTemporalReachability(tg);
//        r_exact = tgreach.getReachability();
        r_exact = TemporalReachability::getReachabilityStream(tgs);
        reachtime = timer.stop();
        saveReachabilities(params.dataset_path, reachtime, r_exact);
    }
    SGLog::log() << "done." << endl;
    SGLog::log() << "Elapsed time: " << reachtime << " s\n";
    auto exact_time = reachtime;


    auto approx_its = params.approx_it;
    if (params.sampling_size != 1.0) {
        approx_its = round(tg.num_nodes * params.sampling_size);
    }
    vector<double> r;
    vector<double> times;

    SGLog::log() << "\nApproximating reachability with " << approx_its << " for " << params.repetitions << " iterations.\n" << flush;

    for (auto j = 0; j < params.repetitions; ++j) {
//        SGLog::log() << "\nApproximating reachability with " << approx_its << " iterations..." << flush;
        std::vector<unsigned int> r_approx;
        r_approx.resize(tg.num_nodes, 0);
        ReachabilityApprox rapp;

        timer.start();
        rapp.approxReachability(tg, r_approx, approx_its, interval_start, interval_end);
//        ReachabilityApprox::approxReachabilityStream(tgs, r_approx, approx_its, interval_start, interval_end);
        auto elapsed = timer.stop();
//        SGLog::log() << "done." << endl;
//        SGLog::log() << "Elapsed time: " << elapsed << " s\n";
        unsigned long total_diff = 0;
        double rel_diff = 0.0;
        for (size_t i = 0; i < r_approx.size(); ++i) {
//            auto diff = labs((long)r_exact.at(i) - (long)r_approx.at(i));
            auto diff = labs((long)r_approx.at(i) - (long)r_exact.at(i));
            total_diff += diff;

            double rd = 0.0;
            if (r_exact[i]>0)
                rd = (double) diff / r_exact[i];
            rel_diff += rd;

        }
        rel_diff = (double)rel_diff / tg.num_nodes;
//        SGLog::log() << total_diff << " " << (double)total_diff / tg.num_nodes << " " << rel_diff << endl;
        r.push_back(rel_diff);
        times.push_back(elapsed);
    }

    double mean, stdev;
    HF::get_mean_std(r, mean, stdev);
    SGLog::log() << "Mean absolute percentage error: " << mean << " +- " << stdev << endl;
//    for (auto &res : r) {
//        SGLog::log() << res << endl;
//    }
    HF::get_mean_std(times, mean, stdev);
    SGLog::log() << "Times: " << mean << " +- " << stdev << endl;
//    SGLog::log() << "Times: " << endl;
//    for (auto &res : times) {
//        SGLog::log() << res << endl;
//    }

    SGLog::log() << "Exact time: " << exact_time << endl;
//    SGLog::log() << "Calculating reachability with stream exactly..." << flush;
//    auto start = std::chrono::steady_clock::now();
//    auto r_stream = TemporalReachability::getReachabilityStream(tgs);
//    auto finish = std::chrono::steady_clock::now();
//    std::chrono::duration<double> elapsed = finish - start;
//    cout << "done." << endl;
//    SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";

}

void reachability_running_time_test(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params) {
    Time interval_start = tgs.edges[0].t;
    Time interval_end = tgs.edges.back().t + tgs.edges.back().traversal_time;
    std::vector<unsigned int> r1, r2;
    {
        TemporalReachability tgreach;
        SGLog::log() << "Calculating reachability exactly..." << flush;
        auto start = std::chrono::steady_clock::now();
        tgreach.initTemporalReachability(tg);
        auto finish = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed = finish - start;
        SGLog::log() << "done." << endl;
        SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
        auto r_exact = tgreach.getReachability();
        if (!params.result_filename.empty())
            HF::writeVectorToFile(params.result_filename, r_exact);
        r1 = tgreach.getReachability();
    }

    {
        TemporalReachability tgreach;
        SGLog::log() << "Calculating reachability with BFS exactly..." << flush;
        for (auto &n : tg.nodes) {
            sort(n.adjlist.begin(), n.adjlist.end(),
                 [](auto const &l, auto const &r) { return l.t < r.t; });
        }
        auto start = std::chrono::steady_clock::now();
        tgreach.initTemporalReachability(tg);
        auto finish = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed = finish - start;
        SGLog::log() << "done." << endl;
        SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
        auto r_exact = tgreach.getReachability();
        if (!params.result_filename.empty())
            HF::writeVectorToFile(params.result_filename, r_exact);

        r2 = tgreach.getReachability();
    }
    for (int i = 0; i < r1.size(); ++i) {
        if (r1.at(i) != r2.at(i))
            cout << r1.at(i) << " " << r2.at(i) << endl;
    }

//    {
//        SGLog::log() << "Calculating reachability with stream exactly..." << flush;
//        auto start = std::chrono::steady_clock::now();
//        auto r_stream = TemporalReachability::getReachabilityStream(tgs);
//        auto finish = std::chrono::steady_clock::now();
//        std::chrono::duration<double> elapsed = finish - start;
//        SGLog::log() << "done." << endl;
//        SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
//    }

    {
        auto approx_its = params.approx_it;
        if (params.sampling_size != 1.0) {
            approx_its = round(tg.num_nodes * params.sampling_size);
        }
        SGLog::log() << "Approximating reachability with " << approx_its << " iterations..." << flush;
        std::vector<unsigned int> r_approx;
        auto start = std::chrono::steady_clock::now();
        r_approx.resize(tg.num_nodes, 0);
        ReachabilityApprox rapp;
        rapp.approxReachability(tg, r_approx, approx_its, interval_start, interval_end);
        auto finish = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed = finish - start;
        SGLog::log() << "done." << endl;
        SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
        if (!params.cmp_filename.empty())
            HF::writeVectorToFile(params.cmp_filename, r_approx);
    }

}
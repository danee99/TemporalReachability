#include <queue>
#include <cassert>
#include <fstream>
#include <iomanip>
#include "TemporalReachability.h"
#include "Paths/LabelPQ.h"
#include "Helpers/SGLog.h"

using namespace std;

void TemporalReachability::initTemporalReachability(TemporalGraph &tg) {

    vector<NodeId> visited(tg.nodes.size(), 0);

    for (std::size_t nid = 0; nid < tg.num_nodes; ++nid) {

        vector<shared_ptr<label>> nodelabels(tg.nodes.size(), nullptr);
        auto l = std::make_shared<label>();
        l->a = 0;
        l->nid = nid;

        nodelabels[nid] = l;

        LabelPQASP q;

        q.push(l);
        vector<Time> earliestArrival(tg.num_nodes, MAX_UINT_VALUE);
        earliestArrival[nid] = 0;
        unsigned int result = 0;

        vector<bool> inQ(tg.nodes.size(), false);
        inQ[nid] = true;

        while (!q.empty()) {
            max_it++;
            auto cur = q.top();
            q.pop();

            assert(q.size() <= tg.num_nodes);

            inQ[cur->nid] = false;

            if (visited[cur->nid] == nid) continue;

            visited[cur->nid] = nid;

            for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {

                if (visited[e.v_id] == nid) continue;

                if (e.t >= cur->a) {
                    if (nodelabels[e.v_id] == nullptr) {
                        auto lnew = std::make_shared<label>();
                        lnew->a = e.t + e.traversal_time;
                        lnew->nid = e.v_id;

                        nodelabels[e.v_id] = lnew;

                        if (tg.nodes[e.v_id].maxTime >= e.t + e.traversal_time) {
                            q.push(lnew);
                            inQ[e.v_id] = true;
                        }

                        earliestArrival[e.v_id] = e.t + e.traversal_time;
                        ++result;
                    } else {
                        if (earliestArrival[e.v_id] > e.t + e.traversal_time) {
                            earliestArrival[e.v_id] = e.t + e.traversal_time;
                            nodelabels[e.v_id]->a = e.t + e.traversal_time;

                            if (tg.nodes[nodelabels[e.v_id]->nid].maxTime >= e.t + e.traversal_time) {
                                if (!inQ[e.v_id]) {
                                    q.push(nodelabels[e.v_id]);
                                    inQ[e.v_id] = true;
                                } else
                                    q.decreasedKey(nodelabels[e.v_id]->pq_pos);
                            }
                        }
                    }
                }
            }
        }

        r.push_back(result);
    }
}


vector<unsigned int> TemporalReachability::getReachability() {
    return r;
}



void initJump(TemporalGraphStream &tgs, vector<unsigned long> &start_pos) {
    start_pos.resize(tgs.num_nodes, MAX_UINT_VALUE);
    unsigned long p = 0;
    for (auto &e : tgs.edges) {
        if (start_pos[e.u_id] == MAX_UINT_VALUE) {
            start_pos[e.u_id] = p;
        }
        p++;
    }
}

vector<unsigned int> TemporalReachability::getReachabilityStream(TemporalGraphStream &tgs) {
    vector<unsigned int> result(tgs.num_nodes, 0);

    for (NodeId nid = 0; nid < tgs.num_nodes; ++nid) {
        unsigned long num_visited = 0;

        vector<Time> minarr(tgs.num_nodes, MAX_UINT_VALUE);
        minarr[nid] = 0;

        for (auto &e : tgs.edges) {

            if (minarr[e.u_id] <= e.t) {
                if (minarr[e.v_id] == MAX_UINT_VALUE) {
                    ++num_visited;
                }
                if (minarr[e.v_id] > e.t + 1) minarr[e.v_id] = e.t + 1;
            }
        }
        result[nid] = num_visited;
    }
    return result;
}


//void TemporalReachability::saveReachabilities(const string &path, double time, std::vector<unsigned int> r) {
//    string name = path + ".reach";
//    std::ofstream fs;
//    fs.open(name);
//    fs << std::setprecision(100);
//    if (!fs.is_open()) {
//        std::cout << "Could not write data to " << name << std::endl;
//        return;
//    }
//    fs << time << std::endl;
//    for (auto &d : r) fs << d << std::endl;
//    fs.close();
//    cout << "Saved reachability to " << name << endl;
//}

//bool TemporalReachability::loadReachabilities(const string &path, double &elapsed1) {
//    string name = path + ".reach";
//    std::ifstream fs;
//    fs.open(name);
//    if (!fs.is_open()) {
//        SGLog::log() << "Did not load reachability file " << name << std::endl;
//        return false;
//    }
//    std::string line;
//    getline(fs, line);
//    elapsed1 = stod(line);
//    while (getline(fs, line)) {
//        unsigned long val = stoul(line);
//        r.push_back(val);
//    }
//    fs.close();
//    SGLog::log() << "Load reachability file " << name << std::endl;
//    return true;
//}


//
// Created by lutz on 10.12.19.
//

#ifndef CENTRALITY_TEMPORALREACHABILITY_H
#define CENTRALITY_TEMPORALREACHABILITY_H

#include "TemporalGraph/TemporalGraphs.h"
#include <list>

class TemporalReachability {

public:

    void initTemporalReachability(TemporalGraph &tg);

    static std::vector<unsigned int> getReachabilityStream(TemporalGraphStream &tgs);

    std::vector<unsigned int> getReachability();

    unsigned long max_it = 0;

//    static void saveReachabilities(const std::string &path, double elapsed1, std::vector<unsigned int> r);
//
//    bool loadReachabilities(const std::string &path, double &elapsed1);

private:

    std::vector<unsigned int> r;

    std::vector<unsigned long> start_pos;


};


#endif //CENTRALITY_TEMPORALREACHABILITY_H

#ifndef CENTRALITY_LABELPQ_H
#define CENTRALITY_LABELPQ_H

#include "TemporalGraph/TemporalGraphs.h"
#include <list>
#include <cassert>
#include <memory>
#include <set>
#include <queue>

struct label {
    NodeId nid = MAX_UINT_VALUE;
    EdgeId eid = MAX_UINT_VALUE;
    NodeId pid = MAX_UINT_VALUE;
    Time s = 0, a = 0, d = 0;
    size_t pq_pos = 0;
    bool deleted = false;
};

class LabelPQSP2 {

public:

    ~LabelPQSP2() {
        data.clear();
    }

    void push(const std::shared_ptr<label> &t) {
        data.push_back(t);
        t->pq_pos = data.size() - 1;
        heapifyUp(data.size() - 1);
    }

    std::shared_ptr<label>& top() {
        return data[0];
    }

    bool empty() {
        return data.empty();
    }

    size_t size() {
        return data.size();
    }

    void pop() {
        data[0] = data.back();
        data[0]->pq_pos = 0;
        data.pop_back();
        heapifyDown();
    }

private:

    std::vector<std::shared_ptr<label>> data;

    void heapifyUp(size_t p) {
        size_t child = p;
        size_t parent = getParent(child);

        while (child >= 0 && parent >= 0 && data[child]->d < data[parent]->d) {
            swap(child, parent);
            child = parent;
            parent = getParent(child);
        }
    }

    void heapifyDown(size_t p = 0) {
        int length = data.size();
        while (true) {
            int left = getLeftChild(p);
            int right = getRightChild(p);
            int smallest = p;

            if (left < length && data[left]->d < data[smallest]->d )
                smallest = left;

            if (right < length && data[right]->d < data[smallest]->d )
                smallest = right;

            if (smallest != p) {
                swap(smallest, p);
                p = smallest;
            } else break;
        }
    }

    static size_t getParent(size_t child) {
        if (child == 0) return 0;
        if (child % 2 == 0)
            return (child / 2) - 1;
        else
            return child / 2;
    }

    static size_t getLeftChild(size_t parent){
        return 2 * parent + 1;
    }

    static size_t getRightChild(size_t parent){
        return 2 * parent + 2;
    }

    void swap(size_t a, size_t b) {
        data[a]->pq_pos = b;
        data[b]->pq_pos = a;
        data[a].swap(data[b]);
    }

};


class LabelPQSP2List {

public:

    ~LabelPQSP2List() {
        data.clear();
    }

    void push(const std::shared_ptr<label> &t) {
        data.push_back(t);
    }

    std::shared_ptr<label>& top() {
        return data.back();
    }

    bool empty() {
        return data.empty();
    }

    size_t size() {
        return data.size();
    }

    void pop() {
//        data.pop_front();
        data.pop_back();
    }

    void decreasedKey(size_t pos) {
        // empty method
    }

private:

//    std::list<std::shared_ptr<label>> data;
    std::vector<std::shared_ptr<label>> data;

};


class LabelPQASP {

public:

    void push(std::shared_ptr<label> &t) {
        data.push_back(t);
        t->pq_pos = data.size() - 1;
        heapifyUp(data.size() - 1);
    }

    std::shared_ptr<label>& top() {
        return data[0];
    }

    bool empty() {
        return data.empty();
    }

    size_t size() {
        return data.size();
    }

    void pop() {
        data[0] = data.back();
        data[0]->pq_pos = 0;
        data.pop_back();
        heapifyDown();
    }

    void decreasedKey(size_t pos) {
        heapifyUp(pos);
    }

private:

    std::vector<std::shared_ptr<label>> data;

    void heapifyUp(size_t p) {
        size_t child = p;
        size_t parent = getParent(child);

        while (child >= 0 && parent >= 0 && data[child]->a < data[parent]->a) {
            swap(child, parent);
            child = parent;
            parent = getParent(child);
        }
    }

    void heapifyDown(size_t p = 0) {
        int length = data.size();
        while (true) {
            int left = getLeftChild(p);
            int right = getRightChild(p);
            int smallest = p;

            if (left < length && data[left]->a < data[smallest]->a)
                smallest = left;

            if (right < length && data[right]->a < data[smallest]->a)
                smallest = right;

            if (smallest != p) {
                swap(smallest, p);
                p = smallest;
            } else break;
        }
    }

    static size_t getParent(size_t child) {
        if (child == 0) return 0;
        if (child % 2 == 0)
            return (child / 2) - 1;
        else
            return child / 2;
    }

    static size_t getLeftChild(size_t parent){
        return 2 * parent + 1;
    }

    static size_t getRightChild(size_t parent){
        return 2 * parent + 2;
    }

    void swap(size_t a, size_t b) {
        data[a]->pq_pos = b;
        data[b]->pq_pos = a;
        data[a].swap(data[b]);
    }
};

class LabelPQASPList {

public:

    ~LabelPQASPList() {
        data.clear();
    }

    void push(const std::shared_ptr<label> &t) {
        data.push_back(t);
    }

    std::shared_ptr<label>& top() {
        return data.back();
    }

    bool empty() {
        return data.empty();
    }

    size_t size() {
        return data.size();
    }

    void pop() {
//        data.pop_front();
        data.pop_back();
    }

private:

    std::vector<std::shared_ptr<label>> data;

};

#endif //CENTRALITY_LABELPQ_H

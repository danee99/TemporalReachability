#include <chrono>
#include "FastestPath.h"
#include "LabelPQ.h"
#include "Helpers/SGLog.h"
#include <set>
#include <cmath>
#include <numeric>

using namespace std;

//void FastestPath::compareFastestPathAlgorithms() {
//    vector<double> running_times_our;
//    vector<double> running_times_baseline;
//    double avg_ours = 0.0;
//    double avg_baseline = 0.0;
//    cout << "Running Fastest Paths" << endl;
//    int i = 0;
//    int c = 0;
//    for (auto &p : startEndVertices) {
//        if (tg.nodes.at(p.first).adjlist.empty()) continue;
//        ++c;
////        cout << intervals.at(i).first << " " << intervals.at(i).second << endl;
//        auto t1 = fastestPath(p.first, intervals.at(i).first, intervals.at(i).second);
//        running_times_our.push_back(t1);
//        avg_ours += t1;
////        cout << t1 << endl;
////        auto t2 = fastestPathNew1(p.first, intervals.at(i).first, intervals.at(i).second);
//        auto t2 = fastestPathStream(p.first, intervals.at(i).first, intervals.at(i).second);
////        auto t2 = fastestPathStreamWithTT(p.first, intervals.at(i).first, intervals.at(i).second);
////        auto t2 = fastestPathStreamWithTTactive(p.first, intervals.at(i).first, intervals.at(i).second);
//        running_times_baseline.push_back(t2);
//        avg_baseline += t2;
////        cout << t2 << endl << endl;
//        ++i;
//    }
//    double sum = std::accumulate(std::begin(running_times_our), std::end(running_times_our), 0.0);
//    double m =  sum / running_times_our.size();
//
//    double accum = 0.0;
//    std::for_each (std::begin(running_times_our), std::end(running_times_our), [&](const double d) {
//        accum += (d - m) * (d - m);
//    });
//
//    double stdev = sqrt(accum / (running_times_our.size()));
//
//    double sum2 = std::accumulate(std::begin(running_times_baseline), std::end(running_times_baseline), 0.0);
//    double m2 =  sum2 / running_times_baseline.size();
//
//    double accum2 = 0.0;
//    std::for_each (std::begin(running_times_baseline), std::end(running_times_baseline), [&](const double d) {
//        accum2 += (d - m2) * (d - m2);
//    });
//
//    double stdev2 = sqrt(accum2 / (running_times_baseline.size()));
//
//    avg_ours /= c; //startEndVertices.size();
//    avg_baseline /= c; //startEndVertices.size();
//    SGLog::log() << "ours:\t" << avg_ours << " \t +-" << stdev << endl;
//    SGLog::log() << "baseline:\t" << avg_baseline << " \t +-" << stdev2 << endl;
//
//
//}

void FastestPath::compareFastestPathAlgorithms() {
    vector<double> running_times_our;
    vector<double> running_times_baseline;
    double avg_ours = 0.0;
    double avg_baseline = 0.0;
    cout << "Running Fastest Paths" << endl;
    Time interval_start = 0;
    Time interval_end = tgs.edges.back().t + tgs.edges.back().traversal_time;
    int i = 0;
    int c = 0;
    for (uint i = 0; i < 1000; i++) {
        NodeId nid = rand() % tgs.num_nodes;
        ++c;
        auto t1 = fastestPath(nid, interval_start, interval_end);
        running_times_our.push_back(t1);
        avg_ours += t1;
//        cout << t1 << endl;
//        auto t2 = fastestPathNew1(p.first, intervals.at(i).first, intervals.at(i).second);
        auto t2 = fastest_path_org(nid, interval_start, interval_end);
//        auto t2 = fastestPathStreamWithTT(p.first, intervals.at(i).first, intervals.at(i).second);
//        auto t2 = fastestPathStreamWithTTactive(p.first, intervals.at(i).first, intervals.at(i).second);
        running_times_baseline.push_back(t2);
        avg_baseline += t2;
//        cout << t2 << endl << endl;
        ++i;
    }
    double sum = std::accumulate(std::begin(running_times_our), std::end(running_times_our), 0.0);
    double m =  sum / running_times_our.size();

    double accum = 0.0;
    std::for_each (std::begin(running_times_our), std::end(running_times_our), [&](const double d) {
        accum += (d - m) * (d - m);
    });

    double stdev = sqrt(accum / (running_times_our.size()));

    double sum2 = std::accumulate(std::begin(running_times_baseline), std::end(running_times_baseline), 0.0);
    double m2 =  sum2 / running_times_baseline.size();

    double accum2 = 0.0;
    std::for_each (std::begin(running_times_baseline), std::end(running_times_baseline), [&](const double d) {
        accum2 += (d - m2) * (d - m2);
    });

    double stdev2 = sqrt(accum2 / (running_times_baseline.size()));

    avg_ours /= c; //startEndVertices.size();
    avg_baseline /= c; //startEndVertices.size();
    SGLog::log() << "ours total:\t" << sum << endl;
    SGLog::log() << "baseline total:\t" << sum2 << endl;
    SGLog::log() << "ours:\t" << avg_ours << " \t +-" << stdev << endl;
    SGLog::log() << "baseline:\t" << avg_baseline << " \t +-" << stdev2 << endl;


}

void FastestPath::compareFastestPathAlgorithmsHighDegree() {
    vector<pair<NodeId, unsigned long>> perm;

    for (auto &n : tg.nodes) {
        perm.emplace_back(n.id, n.adjlist.size());
        if (n.adjlist.empty()) {
            n.maxTime = n.minTime = 0;
        }
    }
    std::sort(perm.begin(), perm.end(), [](const pair<NodeId, unsigned int> & a, const pair<NodeId, unsigned int> & b) -> bool {
        return a.second > b.second;
    });

    vector<double> running_times_our;
    vector<double> running_times_baseline;
    double avg_ours = 0.0;
    double avg_baseline = 0.0;
    cout << "Running Fastest Paths" << endl;
    Time interval_start = 0;
    Time interval_end = tgs.edges.back().t + tgs.edges.back().traversal_time;
    int i = 0;
    int c = 0;
    for (uint i = 0; i < 1000; i++) {
        NodeId nid = perm[i].first;

//        if (tg.nodes.at(nid).adjlist.empty()) continue;
        ++c;
//        cout << intervals.at(i).first << " " << intervals.at(i).second << endl;
        auto t1 = fastestPath(nid, interval_start, interval_end);
        running_times_our.push_back(t1);
        avg_ours += t1;
//        cout << t1 << endl;
//        auto t2 = fastestPathNew1(p.first, intervals.at(i).first, intervals.at(i).second);
        auto t2 = fastest_path_org(nid, interval_start, interval_end);
//        auto t2 = fastestPathStreamWithTT(p.first, intervals.at(i).first, intervals.at(i).second);
//        auto t2 = fastestPathStreamWithTTactive(p.first, intervals.at(i).first, intervals.at(i).second);
        running_times_baseline.push_back(t2);
        avg_baseline += t2;
//        cout << t2 << endl << endl;
        ++i;
    }
    double sum = std::accumulate(std::begin(running_times_our), std::end(running_times_our), 0.0);
    double m =  sum / running_times_our.size();

    double accum = 0.0;
    std::for_each (std::begin(running_times_our), std::end(running_times_our), [&](const double d) {
        accum += (d - m) * (d - m);
    });

    double stdev = sqrt(accum / (running_times_our.size()));

    double sum2 = std::accumulate(std::begin(running_times_baseline), std::end(running_times_baseline), 0.0);
    double m2 =  sum2 / running_times_baseline.size();

    double accum2 = 0.0;
    std::for_each (std::begin(running_times_baseline), std::end(running_times_baseline), [&](const double d) {
        accum2 += (d - m2) * (d - m2);
    });

    double stdev2 = sqrt(accum2 / (running_times_baseline.size()));

    avg_ours /= c; //startEndVertices.size();
    avg_baseline /= c; //startEndVertices.size();
    SGLog::log() << "ours total:\t" << sum << endl;
    SGLog::log() << "baseline total:\t" << sum2 << endl;
    SGLog::log() << "ours:\t" << avg_ours << " \t +-" << stdev << endl;
    SGLog::log() << "baseline:\t" << avg_baseline << " \t +-" << stdev2 << endl;


}


void FastestPath::initStartEndVertices(unsigned int num, unsigned int mode) {
    if (num > tg.num_nodes) num = tg.num_nodes;
    if (mode == 0) {
        vector<bool> seen(tg.num_nodes, false);
        for (size_t i = 0; i < num; ++i) {
            NodeId u = rand() % tg.num_nodes;
            while (seen.at(u)) u = (u + 1) % tg.num_nodes;
            seen.at(u) = true;
            NodeId v = rand() % tg.num_nodes;
            while (seen.at(v)) v = (v + 1) % tg.num_nodes;
            seen.at(v) = true;
            startEndVertices.emplace_back(u, v);
        }
    } else {
        vector<pair<NodeId, unsigned int>> perm;
        for (TGNode &n : tg.nodes) {
            perm.emplace_back(n.id, n.adjlist.size());
        }
        std::stable_sort(perm.begin(), perm.end(),
                         [](const pair<NodeId, unsigned int> &a, const pair<NodeId, unsigned int> &b) -> bool {
                             return a.second > b.second;
                         });
        for (size_t i = 0; i < num; ++i) {
            startEndVertices.emplace_back(perm.at(i).first, 0);
        }
    }
}


double FastestPath::fastestPath(NodeId u, Time interval_start, Time interval_end) {
    auto start = std::chrono::steady_clock::now();

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration[u] = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = u;

    nodelabels.at(u).push_back(l);

    LabelPQSP2 q;

    q.push(l);

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    unsigned long max_q_size = 0;

    while (!q.empty()) {

        if (q.size() > max_q_size)
            max_q_size = q.size();

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }
        visited.at(cur->nid) = true;

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {

            if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;

//            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id]>= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels[e.v_id].begin();
                while (i != nodelabels[e.v_id].end()) {

                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels.at(e.v_id).erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    nodelabels[e.v_id].push_back(lnew);
                    minduration[e.v_id] = minduration[e.v_id] < lnew->d ? minduration[e.v_id] : lnew->d;
                    if (tg.nodes[lnew->nid].maxTime >= lnew->a)
                        q.push(lnew);
                }
            }
        }
    }

    auto finish = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed = finish - start;

    return elapsed.count();
}


double FastestPath::fastestPathStream(NodeId u, Time interval_start, Time interval_end) {
    auto start = std::chrono::steady_clock::now();

    vector<Time> minduration(tg.num_nodes, MAX_UINT_VALUE);
    minduration.at(u) = 0;

    vector<list<shared_ptr<label>>> labels(tg.num_nodes, list<shared_ptr<label>>());

    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = u;

    labels.at(u).push_back(l);

    for (TemporalEdge &e : tgs.edges) {

        if (e.t < interval_start || e.t + 1 > interval_end) continue;

        if (labels.at(e.u_id).empty()) {
            continue;
        }

        auto i = labels.at(e.u_id).begin();
        if (labels.at(e.u_id).size() > 1 && (*i)->a <= e.t) {
            auto i2 = labels.at(e.u_id).begin();
            ++i2;

            while (true) {
                if ((*i2)->a <= e.t) i = labels.at(e.u_id).erase(i);

                ++i2;
                if (i2 == labels.at(e.u_id).end() || (*i2)->a > e.t) {
                    break;
                }
            }

        }
        if (i == labels.at(e.u_id).end() || (*i)->a > e.t) continue;

        auto a = std::make_shared<label>();
        a->nid = e.v_id;
        if ((*i)->nid == u) a->s = e.t;
        else a->s = (*i)->s;
        a->a = e.t + 1;
        a->d = a->a - a->s;

        if (labels.at(e.v_id).empty()) {
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = a->d;
            continue;
        }

        auto b = labels.at(e.v_id).back();
        if ((a->s < b->s && a->a >= b->a) || (a->s == b->s && a->a > b->a)) {
            // b dominates a
            continue;
        } else if ((b->s < a->s && b->a >= a->a) || (b->s == a->s && b->a > a->a)) {
            // a dominates b
            labels.at(e.v_id).pop_back();
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
        } else {
            // keep both
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
        }
    }

    auto finish = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed = finish - start;

    Time durTotal = 0;
    for (std::size_t nid = 0; nid < tgs.num_nodes; ++nid) {
        if (minduration.at(nid) < MAX_UINT_VALUE)
            durTotal += minduration.at(nid);
    }
//    cout << durTotal << endl;

    return elapsed.count();
}

double FastestPath::fastest_path_org(NodeId nid, Time interval_start, Time interval_end) {
    Timer timer;
    timer.start();
    vector <Time> f_time(tgs.num_nodes, MAX_UINT_VALUE);
    vector<set<pair<Time, Time>>> ft_timepair(tgs.num_nodes, set<pair<Time, Time>>());

    f_time[nid]=0;

    set < pair< Time, Time > >::iterator it_tp, it_tp_low, it_tp_up, it_tp_1, it_tp_2;

    for(auto & e : tgs.edges) {

        if(e.t<interval_end){
            if (e.t+e.traversal_time<=interval_end && e.t >=interval_start){
                if (e.u_id == nid){
                    ft_timepair[e.u_id].insert(make_pair(e.t, e.t));
                }

                if(!ft_timepair[e.u_id].empty()){ // the path from x to u is not empty
                    it_tp=ft_timepair[e.u_id].upper_bound(make_pair(e.t, MAX_UINT_VALUE));

                    if(it_tp != ft_timepair[e.u_id].begin()){ //exists some pair arrived at or before t
                        it_tp --;

                        Time a_t=e.t+e.traversal_time;
                        Time s_t=it_tp->second;

                        if(a_t-s_t < f_time[e.v_id])
                            f_time[e.v_id] = a_t-s_t;

                        if(!ft_timepair[e.v_id].empty()){ // the path from x to v is not empty
                            it_tp_1=ft_timepair[e.v_id].lower_bound(make_pair(a_t, s_t));

                            if(it_tp_1 == ft_timepair[e.v_id].begin() ){ // a_t is the smallest arrival time
                                if (it_tp_1->first>a_t){ // the arrival time of it_tp_1 is larger than a_t
                                    it_tp_low=it_tp_1;
                                    for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                        if(it_tp_up->second > s_t){
                                            break;
                                        }
                                    }

                                    ft_timepair[e.v_id].erase(it_tp_low,it_tp_up); //remove useless pairs
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                            }
                            else if (it_tp_1 == ft_timepair[e.v_id].end()) { //a_t is the largest arrival time
                                it_tp_2 = it_tp_1;
                                it_tp_2 --;
                                if(it_tp_2->first == a_t) {
                                    ft_timepair[e.v_id].erase(it_tp_2);
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                                else if (it_tp_2->second < s_t){
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                            }
                            else {
                                if(it_tp_1->first > a_t) { // it_tp_1->first > a_t
                                    it_tp_2=it_tp_1;
                                    it_tp_2--;

                                    if(it_tp_2->first == a_t) {
                                        it_tp_low=it_tp_1;
                                        for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                            if(it_tp_up->second > s_t){
                                                break;
                                            }
                                        }

                                        ft_timepair[e.v_id].erase(it_tp_2, it_tp_up);
                                        ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                    }
                                    else if (it_tp_2->second < s_t){ // it_tp_2->first < a_t
                                        it_tp_low=it_tp_1;
                                        for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                            if(it_tp_up->second > s_t){
                                                break;
                                            }
                                        }

                                        ft_timepair[e.v_id].erase(it_tp_low, it_tp_up);
                                        ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                    }
                                }
                            }
                        }
                        else {
                            ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                        }

                    }
                }


            }
        }
        else {
            break;
        }
    }
    return timer.stop();
}


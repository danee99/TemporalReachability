#ifndef CENTRALITY_FASTESTPATH_H
#define CENTRALITY_FASTESTPATH_H

#include <cassert>
#include "TemporalGraph/TemporalGraphs.h"

class FastestPath {

public:

    explicit FastestPath(TemporalGraphStream &tgs) : tgs(tgs) {
        tg = tgs.toTemporalGraph();
    }

    void compareFastestPathAlgorithms();

    void compareFastestPathAlgorithmsHighDegree();

    void initStartEndVertices(unsigned int num, unsigned int mode = 0);

private:

    TemporalGraph tg;

    TemporalGraphStream tgs;

    std::vector<std::pair<NodeId, NodeId>> startEndVertices;

    std::vector<std::pair<Time, Time>> intervals;

    double fastestPath(NodeId u, Time interval_start, Time interval_end);

    double fastestPathStream(NodeId u, Time interval_start, Time interval_end);

    double fastest_path_org(NodeId nid, Time interval_start, Time interval_end);

};

#endif //CENTRALITY_FASTESTPATH_H

#include <Closeness/TemporalClosenessDuration.h>
#include <Helpers/SGLog.h>
#include <cmath>
#include <Centralities/StaticCloseness.h>
#include <Centralities/DegreeCentrality.h>
#include <Helpers/HelperFunctions.h>
#include "SISimulation.h"


using namespace std;

void si_experiment(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params) {
    SGLog::log() << "Running case study experiment" << endl;
    tgs.sort_edges();
    vector<NodeId> infnids_topk;
    vector<NodeId> infnids_rtopk;
    vector<NodeId> infnids_static;
    vector<NodeId> infnids_degree;
    Time interval_start = tgs.edges.front().t;
    Time interval_end = tgs.edges.front().t + tgs.edges.back().t+tgs.edges.back().traversal_time;

    cout << interval_start << " " << interval_end << endl;

    TemporalClosenessDuration tcd;
    auto approx_its = params.approx_it;
    if (params.sampling_size != 1.0) {
        approx_its = round(tg.num_nodes * params.sampling_size);
    }

    auto rtg = tg.toReverseTemporalGraph(interval_start, interval_end);
    auto rtgs = rtg.toStream();

    auto result_topk = tcd.calculateCloseness(tg, tgs, params, interval_start, interval_end);

    StaticCloseness stc;
    auto result_static = stc.calculateCloseness(tg, params.k, interval_start, interval_end,
                                                params.nids_filename);

    infnids_topk = result_topk.topkResult.getAllNids();
//                infnids_rtopk = result_rtopk.topkResult.getAllNids();
    infnids_static = result_static.topkResult.getAllNids();

    DegreeCentrality dc;
    auto result_deg = dc.calculateDegreeCentrality(tg, params.k);
    infnids_degree = result_deg.topkResult.getAllNids();
    while (infnids_degree.size() > params.k) infnids_degree.pop_back();
    while (infnids_static.size() > params.k) infnids_static.pop_back();
    while (infnids_topk.size() > params.k) infnids_topk.pop_back();
//                while (infnids_rtopk.size() > params.k) infnids_rtopk.pop_back();

    cout << infnids_topk.size() << " " << infnids_static.size() << " " << infnids_degree.size() << endl;
    auto j1 = result_topk.topkResult.countTopkSet(result_static.topkResult);
    auto j2 = result_topk.topkResult.countTopkSet(result_deg.topkResult);
    auto j3 = result_static.topkResult.countTopkSet(result_deg.topkResult);
    cout << j1 << " " << j2 << " " << j3 << endl;

    auto steps = params.cs_steps;

    Time start_time = 0 ; //interval_end + 1;

    vector<vector<unsigned long>> rnd_results;
    vector<vector<unsigned long>> rnd_topk;
    vector<vector<unsigned long>> rnd_static;
    vector<vector<unsigned long>> rnd_deg;

    auto rounds = 100;

    for (int j = 0; j < rounds; j++) {

        vector<NodeId> rnd;
        rnd.reserve(params.k);
        for (auto k = 0; k < params.k; ++k)
            rnd.push_back(rand() % tgs.num_nodes);

        auto inf_rnd = SISimulation::runSISim(tgs, rnd,  steps, start_time);
        auto inf_topk = SISimulation::runSISim(tgs, infnids_topk,  steps, start_time);
        auto inf_static = SISimulation::runSISim(tgs, infnids_static,  steps, start_time);
        auto inf_deg = SISimulation::runSISim(tgs, infnids_degree,  steps, start_time);
        rnd_results.push_back(inf_rnd);
        rnd_topk.push_back(inf_topk);
        rnd_static.push_back(inf_static);
        rnd_deg.push_back(inf_deg);
    }


    vector<string> lines;
    string line0 = (R"(Timestep "Temporal closeness" "Static closeness" "Degree centrality" "Random Avg.")");
    lines.push_back(line0);
    for (auto i = 0; i < rnd_topk.at(0).size(); ++i) {
        double inf_rnd_mean = 0.0;
        double inf_static_mean = 0.0;
        double inf_topk_mean = 0.0;
        double inf_deg_mean = 0.0;
        for (int j = 0; j < rounds; j++) {
            inf_rnd_mean += rnd_results.at(j).at(i);
            inf_static_mean += rnd_static.at(j).at(i);
            inf_topk_mean += rnd_topk.at(j).at(i);
//                        inf_rtopk_mean += rnd_topk.at(j).at(i);
            inf_deg_mean += rnd_deg.at(j).at(i);
        }
        inf_rnd_mean /= (double) rounds;
        inf_static_mean /= (double) rounds;
        inf_topk_mean /= (double) rounds;
        inf_deg_mean /= (double) rounds;

        string line = to_string(start_time + i) + " " + to_string(inf_topk_mean) + " " + to_string(inf_static_mean) + " " + to_string(inf_deg_mean) + " " + to_string(inf_rnd_mean);
        lines.push_back(line);
    }

    if (!params.result_filename.empty())
        HF::writeVectorToFile(params.result_filename, lines);
}
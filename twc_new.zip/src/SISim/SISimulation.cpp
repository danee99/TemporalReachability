#include "SISimulation.h"

using namespace std;

vector<unsigned long> SISimulation::runSISim(TemporalGraphStream &tgs, const std::vector<NodeId>& infected_nids, Time steps, Time start_time) {

    long prob = 10;
    vector<unsigned long> infections_over_time;
    unsigned long newly_infected = infected_nids.size();
    infections_over_time.push_back(newly_infected);

    vector<unsigned int> node_labels(tgs.num_nodes, 0);

    for (unsigned int infected_nid : infected_nids) {
        node_labels.at(infected_nid) = 1;
    }

    Time ft;
    for (TemporalEdge &e : tgs.edges) {
        if (e.t >= start_time) {
            ft = e.t;
            break;
        }
    }

    for (TemporalEdge &e : tgs.edges) {
        if (e.t >= ft) {
            long p = rand() % 100;

            if (node_labels.at(e.u_id) > start_time && node_labels.at(e.u_id) <= e.t && node_labels.at(e.v_id) == 0 && p < prob) {
                node_labels.at(e.v_id) = e.t + e.traversal_time;
                newly_infected++;
            }
            infections_over_time.push_back(newly_infected);
        }
        if (e.t != ft) {
            steps--;
            ft = e.t;
        }
        if (steps == 0) break;
    }
    return infections_over_time;
}

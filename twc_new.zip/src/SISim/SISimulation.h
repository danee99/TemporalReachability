#ifndef CENTRALITY_SISIMULATION_H
#define CENTRALITY_SISIMULATION_H
#include "TemporalGraph/TemporalGraphs.h"

class SISimulation {

public:

    //spread
    static std::vector<unsigned long> runSISim(TemporalGraphStream &tgs, const std::vector<NodeId>& infected_nids, Time steps, Time start_time);

};


#endif //CENTRALITY_SISIMULATION_H

#ifndef CENTRALITY_SIEXPERIMENT_H
#define CENTRALITY_SIEXPERIMENT_H

void si_experiment(TemporalGraphStream &tgs, TemporalGraph &tg, Params const &params);

#endif //CENTRALITY_SIEXPERIMENT_H

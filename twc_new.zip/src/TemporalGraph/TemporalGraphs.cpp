/**
This file is part of TGKernel.
Copyright (C) 2019 Lutz Oettershagen
Contact: lutz.oettershagen@tu-dortmund.de
**/

#include "TemporalGraphs.h"
#include <string>
#include <unordered_map>

using namespace std;

void TGNode::addEdge(const TemporalEdge& e) {
    adjlist.push_back(e);
    if (e.t < minTime) minTime = e.t;
    if (e.t > maxTime) maxTime = e.t;
}

TemporalGraphStream TemporalGraph::toStream() {
    TemporalGraphStream tgs;
    for (TGNode &n : nodes) {
        for (TemporalEdge &e : n.adjlist) {
            tgs.edges.push_back(e);
        }
    }
    tgs.sort_edges();
    tgs.num_nodes = num_nodes;
    return tgs;
}

unsigned int TGNode::getNumNeighbors() {
    std::unordered_set<NodeId> nh;
    for (auto &e :adjlist) nh.insert(e.v_id);
    return nh.size();
}

std::pair<unsigned int, Time> TGNode::getNumNeighborsAndMinDur() {
    std::unordered_set<NodeId> nh;
    Time minDur = MAX_UINT_VALUE;
    for (auto &e :adjlist) {
        nh.insert(e.v_id);
        if (e.traversal_time < minDur) minDur = e.traversal_time;
    }
    if (minDur == MAX_UINT_VALUE) minDur = 1;
    return {nh.size(), minDur};
}

//void TemporalGraph::loadEdgeStream() {
//    for (auto &n : nodes) {
//        for (size_t i = 1; i < n.adjlist.size(); ++i) {
//            auto *e = &n.adjlist.at(i - 1);
//            auto *f = &n.adjlist.at(i);
//            e->next = f;
//            edgeStream.push_back(e);
//        }
//        if (!n.adjlist.empty())
//            edgeStream.push_back(&n.adjlist.back());
//
//    }
//    std::stable_sort(edgeStream.begin(), edgeStream.end(), [](const TemporalEdge * a, const TemporalEdge * b) -> bool { return a->t < b->t; });
//}

//void TemporalGraphStream::make_simple() {
//    TemporalEdges tes;
//    std::stable_sort(edges.begin(), edges.end(), [](const TemporalEdge & a, const TemporalEdge & b) -> bool {
//        return a.v_id < b.v_id;
//    });
//    std::stable_sort(edges.begin(), edges.end(), [](const TemporalEdge & a, const TemporalEdge & b) -> bool {
//        return a.u_id < b.u_id;
//    });
//    for (size_t i = 0; i < edges.size()-1; ++i){
//        TemporalEdge e = edges.at(i);
//        TemporalEdge f = edges.at(i + 1);
//        if (e.u_id != f.u_id || e.v_id != f.v_id || e.t != f.t)
//            tes.push_back(e);
//    }
//    edges.clear();
//    edges.insert(edges.begin(), tes.begin(), tes.end());
//    sort_edges();
//}

TemporalGraph TemporalGraphStream::toTemporalGraph() {
    TemporalGraph g;

    for (unsigned int i = 0; i < num_nodes; ++i) {
        TGNode node;
        node.id = i;
        node.done = false;
        g.nodes.push_back(node);
        g.num_nodes++;
    }

    for (auto &e : edges) {
        g.nodes.at(e.u_id).addEdge(e);
        if (e.t > g.nodes.at(e.u_id).maxTime) g.nodes.at(e.u_id).maxTime = e.t;
        if (e.t < g.nodes.at(e.u_id).minTime) g.nodes.at(e.u_id).minTime = e.t;
    }
    g.num_edges = edges.size();

    Time minD = MAX_UINT_VALUE;
    for (auto &n : g.nodes) {
        for (auto &e : n.adjlist) {
            Time arr = e.t + e.traversal_time;
            NodeId w = e.v_id;
            Time d = MAX_UINT_VALUE;
            for (auto &f : g.nodes.at(w).adjlist) {
                if (f.t >= arr) {
                    if (d > f.t - arr)
                        d = f.t - arr;
                }
            }
            if (minD > d)
                minD = d;
        }
    }
    if (minD == MAX_UINT_VALUE)
        minD = 0;
    cout << "min delta: " << minD << endl;
    g.minTimeDelta = minD;

    return g;
}

//TemporalGraph TemporalGraph::toReverseTemporalGraph() {
//    TemporalGraph rtg;
//    for (TGNode const &n : nodes) {
//        TGNode nnew;
//        nnew.id = n.id;
//        for (TemporalEdge const &e : n.adjlist) {
//            TemporalEdge x;
//            x.v_id = e.v_id;
//            x.u_id = e.u_id;
//            x.t = 1 + max_time - e.t;
//            x.traversal_time = 1;
//            nnew.addEdge(x);
//        }
//        rtg.nodes.push_back(nnew);
//        ++rtg.num_nodes;
//    }
//    return rtg;
//}

TemporalGraph TemporalGraph::toReverseTemporalGraph(Time interval_start, Time interval_end) {
    TemporalGraph rtg;
    TemporalEdges tes;
    Time maxT = 0;
    for (TGNode const &n : nodes) {
        TGNode nnew;
        nnew.id = n.id;
        for (TemporalEdge const &e : n.adjlist) {
            if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;
            TemporalEdge x;
            x.v_id = e.u_id;
            x.u_id = e.v_id;
            x.t = 1 + interval_end - e.t;
//            x.t = 1 + max_time - e.t;
            x.traversal_time = 1;
            x.id = e.id;
            tes.push_back(x);
            rtg.num_edges++;
            if (x.t > maxT)
                maxT = x.t;
        }
        rtg.nodes.push_back(nnew);
        ++rtg.num_nodes;
    }
    for (auto &e : tes) {
        rtg.nodes.at(e.u_id).addEdge(e);
    }
//    rtg.max_time = maxT;
    rtg.num_nodes = num_nodes;
    return rtg;
}


void TemporalGraphStream::sort_edges() {
    std::sort(edges.begin(), edges.end(), [](const TemporalEdge & a, const TemporalEdge & b) -> bool { return a.t < b.t; });
}

TemporalGraphStream TemporalGraphStream::reduceToInterval(Time interval_start, Time interval_end) const {
    TemporalGraphStream tgs;
//    NodeIdManager nodeIdManager;
    unsigned long eid = 0;

    for (auto &e : edges) {
        if (e.t >= interval_start && e.t + e.traversal_time <= interval_end) {
//            NodeId u = nodeIdManager.getNodeId(e.u_id);
//            NodeId v = nodeIdManager.getNodeId(e.v_id);
            NodeId u = e.u_id;
            NodeId v = e.v_id;
            TemporalEdge ne = e;
            ne.u_id = u;
            ne.v_id = v;
            ne.id = eid++;
            tgs.edges.push_back(ne);
        }
    }

//    tgs.num_nodes = nodeIdManager.nid;
    tgs.num_nodes = num_nodes;
    return tgs;
}

TemporalEdges TemporalGraphStream::reduce() {
    TemporalEdges tes;
    std::stable_sort(edges.begin(), edges.end(), [](const TemporalEdge & a, const TemporalEdge & b) -> bool {
        return a.v_id < b.v_id;
    });
    std::stable_sort(edges.begin(), edges.end(), [](const TemporalEdge & a, const TemporalEdge & b) -> bool {
        return a.u_id < b.u_id;
    });
    TemporalEdge le;
    for (TemporalEdge &e : edges) {
        if (e.v_id != le.v_id || e.u_id != le.u_id) {
            le = e;
            tes.push_back(e);
        }
    }
    return tes;
}

TemporalGraphStream TemporalGraphStream::toReverseTemporalGraph() {
    TemporalGraphStream rtgs;
    rtgs.num_nodes = num_nodes;
    Time interval_end = edges.back().t + edges.back().traversal_time;
    for (TemporalEdge const &e : edges) {
        TemporalEdge x;
        x.v_id = e.u_id;
        x.u_id = e.v_id;
        x.t = 1 + interval_end - e.t;
        x.traversal_time = 1;
        x.id = e.id;
        rtgs.edges.push_back(x);
    }
    return rtgs;
}

//std::ostream& operator<<(std::ostream& os, const TemporalGraphStream& tgs) {
//    std::string s1 = "num_nodes\t" + std::to_string(tgs.num_nodes) + "\n";
//    std::string s2 = "num_edges\t" + std::to_string(tgs.edges.size()) + "\n";
////    std::string s3 = "max_time\t" + std::to_string(tgs.get_max_time()) + "\n";
//
//    return os << s1 << s2 /*<< s3*/;
//}

std::ostream& operator<<(std::ostream& os, const TemporalEdge &tgs) {
    std::string s1 = std::to_string(tgs.u_id) + " " + std::to_string(tgs.v_id) + " " + std::to_string(tgs.t) + " " + std::to_string(tgs.traversal_time) + " " + "\n";

    return os << s1;
}

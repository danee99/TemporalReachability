/**
This file is part of TGKernel.
Copyright (C) 2019 Lutz Oettershagen
Contact: lutz.oettershagen@tu-dortmund.de
**/

#ifndef TGKERNEL_GRAPHDATALOADER_H
#define TGKERNEL_GRAPHDATALOADER_H

#include <string>
#include <utility>
#include <vector>
#include <iostream>
#include <algorithm>
#include <limits>
#include <unordered_set>
#include <unordered_map>

#define TG_SIZE_SMALL 225000

using NodeId = unsigned int;
using EdgeId = unsigned int;
using Time = unsigned int;

struct TemporalEdge;
struct TGNode;
using AdjacenceList = std::vector<TemporalEdge>;

static constexpr auto MAX_UINT_VALUE = std::numeric_limits<unsigned int>::max();

//struct NodeIdManager {
//
//    NodeIdManager() : nid(0){};
//
//    std::unordered_map<NodeId, NodeId> nidmap;
//
//    NodeId getNodeId(NodeId id) {
//        NodeId r;
//        if (nidmap.find(id) == nidmap.end()) {
//            r = nid;
//            nidmap.emplace(id, nid++);
//        } else {
//            r = nidmap.at(id);
//        }
//        return r;
//    }
//
//    NodeId nid = 0;
//};

struct TGNode {
    TGNode() = default;
    explicit TGNode(NodeId nid) : id(nid){};
    NodeId id = 0;
    AdjacenceList adjlist;
    Time minTime = MAX_UINT_VALUE;
    Time maxTime = 0;
    bool done = false;
    void addEdge(const TemporalEdge& t);

    unsigned int getNumNeighbors();

    std::pair<unsigned int, Time> getNumNeighborsAndMinDur();
};


struct TemporalEdge {
    TemporalEdge() = default;

    TemporalEdge(NodeId u, NodeId v, Time time, Time tt, EdgeId eid) : u_id(u), v_id(v), t(time),
            traversal_time(tt), id(eid), next(nullptr){  }

    TemporalEdge(NodeId u, NodeId v, Time time, Time tt) : u_id(u), v_id(v), t(time),
            traversal_time(tt), id(0), next(nullptr){  }

    NodeId u_id{}, v_id{};
    Time t{};
    Time traversal_time{};

    bool deleted = false;

    bool operator () ( TemporalEdge const * lhs, TemporalEdge const * rhs ) const {
        return lhs->u_id == rhs->u_id && lhs->v_id == rhs->v_id && lhs->t == rhs->t;
    }

    EdgeId id{};

    TemporalEdge *next = nullptr;

    TemporalEdge(const TemporalEdge& e) : u_id(e.u_id), v_id(e.v_id), t(e.t),
            traversal_time(e.traversal_time), id(e.id), next(e.next) { }
};


using TGNodes = std::vector<TGNode>;
using TemporalEdges = std::vector<TemporalEdge>;

struct TESvec {
    std::vector<NodeId> uids;
    std::vector<NodeId> vids;
    std::vector<NodeId> ts;
};

struct TemporalGraphStream;

struct TemporalGraph {
    TemporalGraph () : num_nodes(0), num_edges(0), nodes(TGNodes()), minTimeDelta(0) {};

    TemporalGraph (const TemporalGraph& tg) {
        for (TGNode const &n : tg.nodes) {
            TGNode nn;
            nn.minTime = n.minTime;
            nn.maxTime = n.maxTime;
            nn.id = n.id;
            nn.done = n.done;
            for (auto &e : n.adjlist) {
                nn.adjlist.push_back(e);
            }
            nodes.push_back(nn);
        }

        num_edges = tg.num_edges;
        num_nodes = tg.num_nodes;
        minTimeDelta = tg.minTimeDelta;
    }

    TGNodes nodes;
    unsigned int num_nodes;
    unsigned int num_edges;
    Time minTimeDelta;

    TemporalGraphStream toStream();
    TemporalGraph toReverseTemporalGraph(Time interval_start, Time interval_end);

};


struct TemporalGraphStream {
    TemporalEdges edges;
    unsigned long num_nodes;

    void sort_edges();
    TemporalGraph toTemporalGraph();
    [[nodiscard]] TemporalGraphStream reduceToInterval(Time interval_start, Time interval_end) const;
    TemporalEdges reduce();

    TemporalGraphStream toReverseTemporalGraph();
};

std::ostream& operator<<(std::ostream& os, const TemporalGraphStream& tgs);
std::ostream& operator<<(std::ostream& os, const TemporalEdge &tgs);



#endif //TGKERNEL_GRAPHDATALOADER_H

//
// Created by noized on 06.11.2019.
//

#ifndef CENTRALITY_TEMPORALGRAPHSTREAMPROVIDER_H
#define CENTRALITY_TEMPORALGRAPHSTREAMPROVIDER_H

#include <cassert>
#include "TemporalGraphs.h"

class TemporalGraphStreamProvider {

public:

    void loadTemporalGraph(const std::string& path, bool directed = true);

    TemporalGraphStream& getTGS() { return tgs; }

    TemporalGraph& getTG() {
//        for (auto e : tg.edgeStream) {
//            assert(e != nullptr);
//            if (e->next != nullptr && e->next->u_id != e->u_id) {
//                std::cout << *e << *e->next << std::endl;
//            }
//            assert(e->next == nullptr || e->next->u_id == e->u_id);
//        }
        return tg;
    }

    void makeSyntheticGraph(unsigned long nodes, unsigned long newnodes, Time maxtime);

private:

    TemporalGraphStream tgs;

    TemporalGraph tg;

//    static TemporalGraphStream normalizeTGS(TemporalGraphStream &tgs);

};

void getFileStream(const std::string& filename, std::ifstream &fs);

#endif //CENTRALITY_TEMPORALGRAPHSTREAMPROVIDER_H

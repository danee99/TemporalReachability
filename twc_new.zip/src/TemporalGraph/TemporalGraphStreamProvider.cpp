//
// Created by noized on 06.11.2019.
//

#include "TemporalGraphStreamProvider.h"
#include "Helpers/HelperFunctions.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <cmath>

using namespace std;

void getFileStream(const string& filename, ifstream &fs) {
    fs.open(filename);
    if (!fs.is_open()) {
        cout << "Could not open data set " << filename << endl;
        exit(EXIT_FAILURE);
    }
}

vector<unsigned long> split_string(const string& s) {
    vector<unsigned long> result;
    stringstream ss(s);
    while (ss.good()) {
        string substr;
        getline(ss, substr, ' ');
        result.push_back(stoul(substr));
    }
    return result;
}

//void TemporalGraphStreamProvider::loadTemporalGraph(std::string path) {
//    ifstream fs;
//    getFileStream(path, fs);
//    string line;
//    getline(fs, line);
//    unsigned long num_nodes = stoul(line);
//    TemporalEdges tes;
//
//    while (getline(fs, line)) {
//        vector<unsigned int> l = split_string(line);
//        NodeId u = l[0];
//        NodeId v = l[1];
//        Time t = l[2];
//        if (t == 0) continue;
//        TemporalEdge e1 = TemporalEdge(u, v, t, 0, 1);
//        TemporalEdge e2 = TemporalEdge(v, u, t, 0, 1);
//        tes.push_back(e1);
//        tes.push_back(e2);
//        tes.at(tes.size()-2).re = &tes.back();
//        tes.back().re = &tes.at(tes.size()-2);
//    }
//    fs.close();
//
//    tgs.edges = tes;
//    tgs.sort_edges();
//    tgs.num_nodes = num_nodes;
//}

void saveRandomGraph(TemporalGraphStream &tgs) {
    string name = "rndtgs_" + to_string(rand()%10000);
    std::ofstream out(name);
    out << std::setprecision(100);
    out << tgs.num_nodes << endl;
    for (auto &e : tgs.edges) {
        out << e.u_id << " " << e.v_id << " " << e.t << " " << e.traversal_time << endl;
    }
    cout << "Saved random graph to " << name << endl;
    out.close();
}

void TemporalGraphStreamProvider::loadTemporalGraph(const std::string& path, bool directed) {
    if (path == "rnd") {
        makeSyntheticGraph(3, pow(2,15)-3, pow(2,16));
//        makeSyntheticGraph(3, 29997, 100000);
        return;
    }
    ifstream fs;
    getFileStream(path, fs);
    string line;
    getline(fs, line);
    unsigned long num_nodes = stoul(line);
    TemporalEdges tes;
    EdgeId eid = 0;

    vector<unsigned long> times;

    while (getline(fs, line)) {
        vector<unsigned long> l = split_string(line);
        NodeId u = l[0];
        NodeId v = l[1];
        Time t = l[2];
        Time tt = l[3];
        TemporalEdge e1 = TemporalEdge(u, v, t+1, tt, eid++);
        tes.push_back(e1);

        if (!directed) {
            TemporalEdge e2 = TemporalEdge(v, u, t + 1, tt, eid++);
            tes.push_back(e2);
        }
    }

    sort(times.begin(), times.end());

    fs.close();
    tgs.edges = tes;
    tgs.sort_edges();
    tgs.num_nodes = num_nodes;
    tg = tgs.toTemporalGraph();
}

void TemporalGraphStreamProvider::makeSyntheticGraph(unsigned long nodes, unsigned long newnodes, Time maxtime) {
    unsigned long nid = 0;
    unsigned long total_degree = 0;
    Time t = 1;
    for (; nid < nodes; nid++) {
        TGNode node(nid);
        tg.nodes.push_back(node);
        tg.num_nodes++;
    }

    for (nid = 0; nid < nodes; nid++) {
        TemporalEdge e(nid, (nid+1) % nodes, t++, 1), f(e.v_id, e.u_id, e.t, e.traversal_time);
        tg.nodes.at(e.u_id).addEdge(e);
        tg.nodes.at(f.u_id).addEdge(f);
        total_degree += 2;
    }

    for (; nid < nodes + newnodes; nid++) {
        TGNode node(nid);
        tg.nodes.push_back(node);
        tg.num_nodes++;
        for (auto &n : tg.nodes) {
            double p = pow((1.0+(double)n.adjlist.size()) / (double)total_degree, 0.9);
            double r = (rand()/(double)(RAND_MAX + 1.0));
            if (p > r) {
                TemporalEdge e(nid, n.id, t++, 1 + rand() % 99), f(e.v_id, e.u_id, e.t, e.traversal_time);
//                TemporalEdge e(nid, n.id, t++, 1 + rand() % 31), f(e.v_id, e.u_id, e.t, e.traversal_time);
//                TemporalEdge e(nid, n.id, 1 + rand() % maxtime, 1), f(e.v_id, e.u_id, e.t, e.traversal_time);
//                TemporalEdge e(nid, n.id, 1 + rand() % maxtime, 1+rand()%10), f(e.v_id, e.u_id, e.t, e.traversal_time);
                tg.nodes.back().addEdge(e);
                tg.nodes.at(f.u_id).addEdge(f);
                total_degree += 2;
            }
        }
    }
    for (auto &n : tg.nodes) {
        if (n.adjlist.empty()) {
            NodeId v = (n.id + 1) % tg.num_nodes;
            TemporalEdge e(n.id, v, t++, 1 + rand() % 99), f(e.v_id, e.u_id, e.t, e.traversal_time);
            tg.nodes.at(n.id).addEdge(e);
            tg.nodes.at(f.u_id).addEdge(f);
        }
    }

    tgs = tg.toStream();
    saveRandomGraph(tgs);
}

//TemporalGraphStream TemporalGraphStreamProvider::normalizeTGS(TemporalGraphStream &tgs) {
//    std::unordered_map<NodeId, NodeId> nidmap;
//    TemporalEdges tes;
//    NodeId nid = 0;
//    EdgeId eid = 0;
//    for (TemporalEdge &e : tgs.edges) {
//        NodeId u = 0, v = 0;
//        if (nidmap.find(e.u_id) == nidmap.end()) {
//            u = nid;
//            nidmap.emplace(e.u_id, nid++);
//        } else {
//            u = nidmap.at(e.u_id);
//        }
//        if (nidmap.find(e.v_id) == nidmap.end()) {
//            v = nid;
//            nidmap.emplace(e.v_id, nid++);
//        } else {
//            v = nidmap.at(e.v_id);
//        }
//        tes.push_back(TemporalEdge(u, v, e.t, e.cost, e.traversal_time, eid++));
//    }
//
//    TemporalGraphStream result;
//    result.edges = tes;
//    result.sort_edges();
//
//    result.num_nodes = nid;
//    return result;
//}
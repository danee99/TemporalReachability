//
// Created by lutz on 17.06.20.
//

#ifndef CENTRALITY_TEMPORALCLOSENESSREVDURATIONNOAPPROX_H
#define CENTRALITY_TEMPORALCLOSENESSREVDURATIONNOAPPROX_H


#include <vector>
#include <Helpers/TopkResult.h>
#include "TemporalGraph/TemporalGraphs.h"

class TemporalClosenessRevDurationNoApprox {

public:

    Result calculateCloseness(TemporalGraph &tg, unsigned int k, Time interval_start, Time interval_end, TemporalGraphStream& tgs);

private:

    void calculateClosenessForNodeNoApprox(TemporalGraph &tg, NodeId nid, Time interval_start, Time interval_end);

    unsigned long max_it = 0;

    std::vector<std::vector<unsigned long>> distances;
};


#endif //CENTRALITY_TEMPORALCLOSENESSREVDURATIONNOAPPROX_H

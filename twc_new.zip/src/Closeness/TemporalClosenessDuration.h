#ifndef CENTRALITY_TEMPORALCLOSENESSDURATION_H
#define CENTRALITY_TEMPORALCLOSENESSDURATION_H


#include "TemporalGraph/TemporalGraphs.h"
#include "Reachability/TemporalReachability.h"
#include "Paths/LabelPQ.h"
#include "Helpers/TopkResult.h"
#include "Helpers/TopkResultDur.h"
#include <unordered_map>
#include <Helpers/Params.h>


class TemporalClosenessDuration {

public:

    Result calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, const Params &params, Time interval_start, Time interval_end);

private:

    void calculateClosenessForNodeApprox6STG(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end);

    void calculateClosenessForNodeApprox6(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end);

    unsigned long max_it = 0;

};


#endif //CENTRALITY_TEMPORALCLOSENESSDURATION_H

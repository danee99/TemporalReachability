//
// Created by lutz on 07.01.21.
//

#ifndef CENTRALITY_TEMPORALCLOSENESSSTREAMJUMP_H
#define CENTRALITY_TEMPORALCLOSENESSSTREAMJUMP_H

#include "TemporalGraph/TemporalGraphs.h"
#include "Helpers/TopkResult.h"

class TemporalClosenessStreamJump {

public:

    Result calculateCloseness(TemporalGraphStream &tgs, unsigned int k, bool unit, Time interval_start, Time interval_end);

private:

    void init(TemporalGraphStream &tgs);

    void calculateClosenessDurationNoApproxTGS(TemporalGraphStream &tg, NodeId nid, TopkResult &result, Time interval_start, Time interval_end);

    void calculateClosenessDurationNoApproxTGS2(TemporalGraphStream &tg, NodeId nid, TopkResult &result, Time interval_start, Time interval_end);

    unsigned long max_it = 0;

    std::vector<unsigned long> start_pos;

};


#endif //CENTRALITY_TEMPORALCLOSENESSSTREAMJUMP_H

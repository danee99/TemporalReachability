#ifndef CENTRALITY_TEMPORALCLOSENESSDURATIONHEURISTICS_H
#define CENTRALITY_TEMPORALCLOSENESSDURATIONHEURISTICS_H


#include <Helpers/TopkResult.h>
#include <Helpers/Params.h>

class TemporalClosenessDurationHeuristics {

public:

    Result calculateClosenessNoBounding(TemporalGraph &tg, TemporalGraphStream& tgs, const Params &params, Time interval_start, Time interval_end);

    Result calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, const Params &params, Time interval_start, Time interval_end);

private:

    void calculateClosenessForNodeApproxHeuristic(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end);

    void calculateClosenessForNodeApproxHeuristic2(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end, unsigned int nodeLabelsNum);

    void calculateClosenessForNodeNoBoundingHeuristicSTG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result);

    void calculateClosenessForNodeNoBoundingHeuristic2STG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, unsigned int nodeLabelsNum);

    unsigned long max_it = 0;

};


#endif //CENTRALITY_TEMPORALCLOSENESSDURATIONHEURISTICS_H

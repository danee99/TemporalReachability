#include "ClosenessEstimator.h"
#include "Paths/LabelPQ.h"
#include "Helpers/SGLog.h"
#include "Helpers/ResultFile.h"
#include <random>
#include <queue>
#include <list>
#include <cassert>
#include <chrono>

using namespace std;


Result ClosenessEstimator::estimateCloseness(TemporalGraph &tg, unsigned int k, double p, Time interval_start, Time interval_end) {
    vector<pair<NodeId, double>> result;

    unsigned long h = round((double)tg.num_nodes * p);

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;
    SGLog::log() << "h: " << h << endl;

    srand((unsigned)time(nullptr) );

    SGLog::log() << "rand 2: " << rand() << endl;

    auto start = std::chrono::high_resolution_clock::now();

    estimateCloseness2(tg, h, result, interval_start, interval_end);

    auto finish1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed1 = finish1 - start;

    TopkResult topkResult(k, h);
    for (auto pair : result) {
        topkResult.insert(pair.second, pair.first);
    }

    topkResult.print();

    SGLog::log() << "Elapsed time: " << elapsed1.count() << " s\n";

    Result rresult(elapsed1.count(), {interval_start, interval_end}, topkResult);
    rresult.all_results = result;
    return rresult;
}

void ClosenessEstimator::estimateCloseness2(TemporalGraph &tg, unsigned int h, vector<pair<NodeId, double>> &result, Time interval_start, Time interval_end) {

    // calculate the temporal reverse graph
    TemporalGraph rtg = tg.toReverseTemporalGraph(interval_start, interval_end);

    // get h random vertices
    for (NodeId nid = 0; nid < tg.num_nodes; ++nid) {
        result.emplace_back(nid, 0.0);
    }

    for (std::size_t i = 0; i < h; ++i) {
        // sample node
        NodeId n = rand() % rtg.num_nodes;

        vector<Time> minduration(rtg.num_nodes, MAX_UINT_VALUE);

        // calculate the durations to all other nodes from each node in nids
        calculateMinDurations(rtg, n, minduration);
//        calculateMinDurationsStream(rtg, n, minduration);

        for (NodeId nid = 0; nid < tg.num_nodes; ++nid) {
            double c = 0.0;

            if (minduration.at(nid) == MAX_UINT_VALUE || minduration.at(nid) == 0) continue;
            c += (double) (1.0 / minduration.at(nid));

            result.at(nid).second += c;
        }
    }
}

void ClosenessEstimator::calculateMinDurationsStream(TemporalGraph &tg1, NodeId nid, vector<Time> &minduration) {
    TemporalGraphStream tg = tg1.toStream();
    minduration.at(nid) = 0;

    vector<list<shared_ptr<label>>> labels(tg.num_nodes, list<shared_ptr<label>>());

    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;

    labels.at(nid).push_back(l);

    for (TemporalEdge &e : tg.edges) {

        if (labels.at(e.u_id).empty()) {
            continue;
        }

        auto i = labels.at(e.u_id).begin();
        if (labels.at(e.u_id).size() > 1 && (*i)->a <= e.t) {
            auto i2 = labels.at(e.u_id).begin();
            ++i2;

            while (true) {
                if ((*i2)->a <= e.t) i = labels.at(e.u_id).erase(i);

                ++i2;
                if (i2 == labels.at(e.u_id).end() || (*i2)->a > e.t) {
                    break;
                }
            }

        }
        if (i == labels.at(e.u_id).end() || (*i)->a > e.t) continue;


        auto a = std::make_shared<label>();
        a->nid = e.v_id;
        if ((*i)->nid == nid) a->s = e.t;
        else a->s = (*i)->s;
        a->a = e.t + 1;
        a->d = a->a - a->s;

        if (labels.at(e.v_id).empty()) {
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = a->d;
            continue;
        }

        auto b = labels.at(e.v_id).back();
        if ((a->s < b->s && a->a >= b->a) || (a->s == b->s && a->a > b->a)) {
            // b dominates a
            continue;
        } else if ((b->s < a->s && b->a >= a->a) || (b->s == a->s && b->a > a->a)) {
            // a dominates b
            labels.at(e.v_id).pop_back();
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
        } else {
            // keep both
            labels.at(e.v_id).push_back(a);
            minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
        }
    }

}

void ClosenessEstimator::calculateMinDurations(TemporalGraph &tg, NodeId nid, vector<Time> &minduration) {

    minduration.at(nid) = 0;
    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid).push_back(l);

    LabelPQSP2 q;
    q.push(l);

    unsigned int num_finished = 1;

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited.at(cur->nid)) {
            visited.at(cur->nid) = true;
            minduration.at(cur->nid) = minduration.at(cur->nid) < cur->d ? minduration.at(cur->nid) : cur->d;
            num_finished++;
            if (num_finished == tg.num_nodes) break;
        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {

            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart.at(e.id) > 0 && edgeMaxStart.at(e.id) >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart.at(e.id) = e.t;
                }
                else {
                    if (edgeMaxStart.at(e.id) < cur->s)
                        edgeMaxStart.at(e.id) = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels.at(e.v_id).begin();
                while (i != nodelabels.at(e.v_id).end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels.at(e.v_id).erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    nodelabels.at(e.v_id).push_back(lnew);
                    if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                        q.push(lnew);
                    else
                    if (!visited.at(e.v_id))
                        minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                }
            }
        }
    }
}

void ClosenessEstimator::estimateCloseness(TemporalGraph &tg, unsigned int h, vector<pair<NodeId, double>> &result, Time interval_start, Time interval_end) {

    // calculate the temporal reverse graph
    TemporalGraph rtg = tg.toReverseTemporalGraph(interval_start, interval_end);

    // get h random vertices
    for (NodeId nid = 0; nid < tg.num_nodes; ++nid) {
        result.emplace_back(nid, 0.0);
    }


    for (std::size_t i = 0; i < h; ++i) {
        // sample node
        NodeId nid = rand() % rtg.num_nodes;

        vector<Time> minduration(rtg.num_nodes, MAX_UINT_VALUE);

        // calculate the durations to all other nodes from each node in nids

        minduration.at(nid) = 0;

        vector<list<shared_ptr<label>>> nodelabels(rtg.nodes.size());
        auto l = std::make_shared<label>();
        l->a = l->s = l->d = 0;
        l->nid = nid;

        nodelabels.at(nid).push_back(l);

        LabelPQSP2 q;
        q.push(l);

        while (!q.empty()) {

            auto cur = q.top();
            q.pop();
            if (cur->deleted) {
                continue;
            }


            for (TemporalEdge &e : rtg.nodes[cur->nid].adjlist) {

                if (cur->pid == e.v_id) continue;

                if (e.t >= cur->a && e.v_id != nid) {

                    auto lnew = std::make_shared<label>();;
                    lnew->nid = e.v_id;
                    lnew->pid = cur->nid;
                    if (cur->s == 0) lnew->s = e.t;
                    else lnew->s = cur->s;
                    lnew->a = e.t + 1;
                    lnew->d = lnew->a - lnew->s;

                    bool dom = false;
                    auto it = nodelabels.at(e.v_id).begin();
                    while (it != nodelabels.at(e.v_id).end()) {
                        if (((*it)->s < lnew->s && (*it)->a == lnew->a) || ((*it)->s == lnew->s && (*it)->a > lnew->a)) {
                            (*it)->deleted = true;
                            nodelabels.at(e.v_id).erase(it++);
                            continue;
                        }
                        if (((*it)->s >= lnew->s && (*it)->a == lnew->a) || ((*it)->s == lnew->s && (*it)->a <= lnew->a)) {
                            dom = true;
                            break;
                        }
                        ++it;
                    }

                    if (!dom) {
                        nodelabels.at(e.v_id).push_back(lnew);
                        minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                        if (rtg.nodes[lnew->nid].maxTime >= e.t + 1)
                            q.push(lnew);
                    }
                }
            }
        }


        for (NodeId n = 0; n < rtg.num_nodes; ++n) {
            double c = 0.0;

            if (minduration.at(n) == MAX_UINT_VALUE || minduration.at(n) == 0) continue;
            c += (double) (1.0 / minduration.at(n));

            result.at(n).second += c;
        }
    }
}


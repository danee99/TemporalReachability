#include "TemporalClosenessDurationHeuristics.h"
#include "Reachability/ReachabilityApprox.h"
#include "Helpers/SGLog.h"
#include "TemporalClosenessDurationNoApprox.h"
#include <list>

using namespace std;

///////////////////////////////////////////////////////////
// with bounding
///////////////////////////////////////////////////////////

Result TemporalClosenessDurationHeuristics::calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, const Params &params, Time interval_start, Time interval_end){

    SGLog::log() << "calculation top-k closeness with bounding and heuristic" << endl;
    Timer timer;
    timer.start();

    vector<pair<NodeId, unsigned long>> perm;

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;

    TopkResult topkResult(params.k, tg.num_nodes);

    max_it = 0;

    for (auto &n : tg.nodes) {
        perm.emplace_back(n.id, n.adjlist.size());
        if (n.adjlist.empty()) {
            n.maxTime = n.minTime = 0;
        }
    }
    std::sort(perm.begin(), perm.end(), [](const pair<NodeId, unsigned int> & a, const pair<NodeId, unsigned int> & b) -> bool {
        return a.second > b.second;
    });

    switch (params.use_heuristic) {
        case 1 : {
            for (auto p : perm) {
                calculateClosenessForNodeApproxHeuristic(tg, p.first, topkResult, interval_start, interval_end);
            }
            break;
        }
        case 2 : {
            for (auto p : perm) {
                calculateClosenessForNodeApproxHeuristic2(tg, p.first, topkResult, interval_start, interval_end, params.heuristic_num_label);
            }
            break;
        }
        default : {
            SGLog::log() << "No heuristic specified! " << endl;
            exit(1);
        }
    }
    auto finish = timer.stop();

    topkResult.print();

    SGLog::log() << "Elapsed time: " << finish << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(finish, {interval_start, interval_end}, topkResult);
    return result;
}

void TemporalClosenessDurationHeuristics::calculateClosenessForNodeApproxHeuristic(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<shared_ptr<label>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid) = l;

    LabelPQSP2 q;
    q.push(l);

    vector<bool> is_T_vertex(tg.num_nodes, false);

    double total_reachable = tg.num_nodes;

    unsigned int num_f = 0;
    unsigned int num_T = 0;
    double exact_closeness = 0.0;
    double cut_edges_approx = 0.0;

    vector<bool> exactAdded(tg.nodes.size(), false);
    vector<Time> edgeMaxStart(tg.num_edges, 0);

    while (!q.empty() && num_f < tg.num_nodes) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (visited.at(cur->nid)) continue;

        if (!visited.at(cur->nid)) {
            visited.at(cur->nid) = true;

            ++num_f;

            if (is_T_vertex[cur->nid]) {
                --num_T;
                cut_edges_approx -= 1.0 / cur->d;
            }

        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            if (visited.at(e.v_id)) continue;

            ++max_it;

            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();;
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                auto old_label = nodelabels.at(e.v_id);

                minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                if (old_label == nullptr || old_label->d > lnew->d) {
                    if (old_label != nullptr) old_label->deleted = true;
                    nodelabels.at(e.v_id) = lnew;
                    q.push(lnew);

                    if (!is_T_vertex[e.v_id] && !visited[e.v_id]) {
                        ++num_T;
                        is_T_vertex[e.v_id] = true;
                    }
                }
            }
        }

        // update estimation for T vertices
        cut_edges_approx = (double)num_T / q.top()->d;

        // update exact closeness
        assert(minduration.at(cur->nid) < MAX_UINT_VALUE);
        if (minduration.at(cur->nid) > 0) {
            if (!exactAdded.at(cur->nid)) {
                exact_closeness += 1.0 / minduration.at(cur->nid);
                exactAdded.at(cur->nid) = true;
            }
        }

        // calculate approx
        if (topkResult.doApproximation()) {

            // calculate rest
            double rest_approx = double (total_reachable - num_f - num_T) / ((double)q.top()->d + 1.0 + tg.minTimeDelta); //todo 2.0
            double total_approx = exact_closeness + cut_edges_approx + rest_approx;

            if (total_approx < topkResult.getMinMaxTopk()) {
                return;
            }
        }
    }

    double closeness = exact_closeness;

    topkResult.insert(closeness, nid);

}


void TemporalClosenessDurationHeuristics::calculateClosenessForNodeApproxHeuristic2(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end, unsigned int nodeLabelsNum) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid).push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<bool> is_T_vertex(tg.num_nodes, false);

    double total_reachable = tg.num_nodes;

    unsigned int num_f = 0;
    unsigned int num_T = 0;
    double exact_closeness = 0.0;
    double cut_edges_approx = 0.0;

    vector<bool> exactAdded(tg.nodes.size(), false);
    vector<Time> edgeMaxStart(tg.num_edges, 0);

    while (!q.empty() && num_f < tg.num_nodes) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited.at(cur->nid)) {
            visited.at(cur->nid) = true;

            ++num_f;

            if (is_T_vertex[cur->nid]) {
                --num_T;
                cut_edges_approx -= 1.0 / cur->d;
            }

        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;
            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();;
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;

                auto i = nodelabels.at(e.v_id).begin();
                while (i != nodelabels.at(e.v_id).end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels.at(e.v_id).erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }

                    ++i;
                }


                if (!dom) {
                    minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                    if (nodelabels.at(e.v_id).size() < nodeLabelsNum) {
                        nodelabels.at(e.v_id).push_back(lnew);
                        q.push(lnew);
                    }

                    if (!is_T_vertex[e.v_id] && !visited[e.v_id]){
                        ++num_T;
                        is_T_vertex[e.v_id] = true;
                    }

                }
            }
        }

        // update estimation for T vertices
        cut_edges_approx = (double)num_T / q.top()->d;

        // update exact closeness
        assert(minduration.at(cur->nid) < MAX_UINT_VALUE);
        if (minduration.at(cur->nid) > 0) {
            if (!exactAdded.at(cur->nid)) {
                exact_closeness += 1.0 / minduration.at(cur->nid);
                exactAdded.at(cur->nid) = true;
            }
        }

        // calculate approx
        if (topkResult.doApproximation()) {

            // calculate rest
            double rest_approx = double (total_reachable - num_f - num_T) / ((double)q.top()->d + 1.0 + tg.minTimeDelta); //todo 2.0
            double total_approx = exact_closeness + cut_edges_approx + rest_approx;

            if (total_approx < topkResult.getMinMaxTopk()) {
                return;
            }
        }
    }

    double closeness = exact_closeness;

    topkResult.insert(closeness, nid);

}




///////////////////////////////////////////////////////////
// without bounding
///////////////////////////////////////////////////////////

Result TemporalClosenessDurationHeuristics::calculateClosenessNoBounding(TemporalGraph &tg, TemporalGraphStream& tgs, Params const &params, Time interval_start, Time interval_end) {
    SGLog::log() << "calculation top-k closeness with heuristic without bounding (calc. all closenesses)" << endl;

    max_it = 0;
    std::vector<std::pair<NodeId, double>> results;
    Timer timer;
    timer.start();

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;

    switch (params.use_heuristic) {
        case 1 : {
            for (TGNode &n : tg.nodes) {
                calculateClosenessForNodeNoBoundingHeuristicSTG(tg, n.id, results);
            }
            break;
        }
        case 2 : {
            for (TGNode &n : tg.nodes) {
                calculateClosenessForNodeNoBoundingHeuristic2STG(tg, n.id, results, params.heuristic_num_label);
            }
            break;
        }
        default : {
            SGLog::log() << "No heuristic specified! " << endl;
            exit(1);
            break;
        }
    }

    auto finish = timer.stop();

    TopkResult topkResult(params.k, tg.num_nodes);
    for (auto pair : results)
        topkResult.insert(pair.second, pair.first);
    topkResult.print();

    std::stable_sort(results.begin(), results.end(), [](const pair<NodeId, double> & a, const pair<NodeId, double> & b) -> bool {
        return a.first < b.first;
    });

    SGLog::log() << "Elapsed time: " << finish << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(finish, {interval_start, interval_end}, topkResult);
    result.all_results = results;
    return result;
}


void TemporalClosenessDurationHeuristics::calculateClosenessForNodeNoBoundingHeuristicSTG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<shared_ptr<label>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid) = l;

    LabelPQSP2List q;
    q.push(l);

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (visited.at(cur->nid)) continue;
        visited.at(cur->nid) = true;
        minduration.at(cur->nid) = minduration.at(cur->nid) < cur->d ? minduration.at(cur->nid) : cur->d;

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            if (visited.at(e.v_id)) continue;

            ++max_it;

            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                auto old_label = nodelabels.at(e.v_id);
                minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                if (old_label == nullptr || old_label->d > lnew->d) {
                    if (old_label != nullptr) old_label->deleted = true;
                    nodelabels.at(e.v_id) = lnew;
                    if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                        q.push(lnew);
                }
            }
        }
    }

    double closeness = 0;

    for (NodeId n = 0; n < tg.nodes.size(); ++n) {
        if (minduration.at(n) > 0 && minduration.at(n) < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration.at(n);
        }
    }

    result.emplace_back(nid, closeness);
}


//void TemporalClosenessDurationHeuristics::calculateClosenessForNodeNoBoundingHeuristic2STG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, unsigned int nodeLabelsNum) {
//
//    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
//    minduration.at(nid) = 0;
//
//    vector<bool> visited(tg.nodes.size(), false);
//
//    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
//    auto l = std::make_shared<label>();
//    l->a = l->s = l->d = 0;
//    l->nid = nid;
//    nodelabels.at(nid).push_back(l);
//
//    LabelPQSP2List q;
//    q.push(l);
//
//    vector<Time> edgeMaxStart(tg.num_edges, 0);
//
//    unsigned int num_finished = 1;
//
//    while (!q.empty()) {
//
//        auto cur = q.top();
//        q.pop();
//        if (cur->deleted) {
//            continue;
//        }
//
////        minduration.at(cur->nid) = minduration.at(cur->nid) < cur->d ? minduration.at(cur->nid) : cur->d;
//        if (!visited[cur->nid]) {
//            visited[cur->nid] = true;
//            minduration[cur->nid] = minduration[cur->nid] < cur->d ? minduration[cur->nid] : cur->d;
//            num_finished++;
//            if (num_finished == tg.num_nodes) break;
//        }
//
//        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
//
//            ++max_it;
//
//            if (cur->pid == e.v_id) continue;
//
//            if (e.t >= cur->a) {
//
//                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
//                    continue;
//                }
//
//                if (cur->s == 0){
//                    edgeMaxStart[e.id] = e.t;
//                }
//                else {
//                    if (edgeMaxStart[e.id] < cur->s)
//                        edgeMaxStart[e.id] = cur->s;
//                }
//
//                auto lnew = std::make_shared<label>();
//                lnew->nid = e.v_id;
//                lnew->pid = cur->nid;
//                if (cur->s == 0) lnew->s = e.t;
//                else lnew->s = cur->s;
//                lnew->a = e.t + e.traversal_time;
//                lnew->d = lnew->a - lnew->s;
//
//                bool dom = false;
//                auto i = nodelabels.at(e.v_id).begin();
//                while (i != nodelabels.at(e.v_id).end()) {
//                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
//                        (*i)->deleted = true;
//                        i = nodelabels.at(e.v_id).erase(i);
//                        continue;
//                    }
//                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
//                        dom = true;
//                        break;
//                    }
//                    ++i;
//                }
//
//                if (!dom) {
//                    if (nodelabels.at(e.v_id).size() < nodeLabelsNum) {
//                        nodelabels.at(e.v_id).push_back(lnew);
//                        if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
//                            q.push(lnew);
//                    }
//                    minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
//                }
//            }
//        }
//    }
//
//    double closeness = 0;
//
//    for (NodeId n = 0; n < tg.nodes.size(); ++n) {
//        if (minduration.at(n) > 0 && minduration.at(n) < MAX_UINT_VALUE) {
//            closeness += 1.0 / minduration.at(n);
//        }
//    }
//
//    result.emplace_back(nid, closeness);
//}


void TemporalClosenessDurationHeuristics::calculateClosenessForNodeNoBoundingHeuristic2STG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, unsigned int nodeLabelsNum) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration[nid] = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels[nid].push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    unsigned int num_finished = 1;

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited[cur->nid]) {
            visited[cur->nid] = true;
            minduration[cur->nid] = minduration[cur->nid] < cur->d ? minduration[cur->nid] : cur->d;
            num_finished++;
            if (num_finished == tg.num_nodes) break;
        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

//            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels[e.v_id].begin();
                while (i != nodelabels[e.v_id].end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels[e.v_id].erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    minduration[e.v_id] = minduration[e.v_id] < lnew->d ? minduration[e.v_id] : lnew->d;

                    if (nodelabels[e.v_id].size() < nodeLabelsNum) {
                        nodelabels[e.v_id].push_back(lnew);
                        if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                            q.push(lnew);
                    }
                }
            }
        }
    }

    double closeness = 0;

    for (NodeId n = 0; n < tg.nodes.size(); ++n) {
        if (minduration[n] > 0 && minduration[n] < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration[n];
        }
    }

    result.emplace_back(nid, closeness);
}

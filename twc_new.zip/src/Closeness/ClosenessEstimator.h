//
// Created by lutz on 20.01.20.
//

#ifndef CENTRALITY_CLOSENESSESTIMATOR_H
#define CENTRALITY_CLOSENESSESTIMATOR_H


#include "TemporalGraph/TemporalGraphs.h"
#include "Helpers/ResultFile.h"


class ClosenessEstimator {

public:

    static Result estimateCloseness(TemporalGraph &tg, unsigned int k, double p, Time interval_start, Time interval_end);

private:

    static void estimateCloseness(TemporalGraph &tg, unsigned int h, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);
    static void estimateCloseness2(TemporalGraph &tg, unsigned int h, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);

    static void calculateMinDurations(TemporalGraph &tg, NodeId nid, std::vector<Time> &minduration);
    static void calculateMinDurationsStream(TemporalGraph &tg, NodeId nid, std::vector<Time> &minduration);

};


#endif //CENTRALITY_CLOSENESSESTIMATOR_H

#include "TemporalClosenessStream.h"
#include "Helpers/SGLog.h"
#include "Reachability/TemporalReachability.h"
#include <list>

using namespace std;

Result TemporalClosenessStream::calculateCloseness(TemporalGraphStream &tgs, unsigned int k, bool unit, Time interval_start, Time interval_end) {
    max_it = 0;

    std::vector<std::pair<NodeId, double>> results;

    Timer timer;
    timer.start();

    SGLog::log() << "# nodes: " << tgs.num_nodes << endl;
    SGLog::log() << "# edges: " << tgs.edges.size() << endl;

    for (NodeId nid = 0; nid < tgs.num_nodes; ++nid) {
        calcClosenessStreamOrg(tgs, nid, results, interval_start, interval_end);
    }
    auto finish = timer.stop();

    TopkResult topkResult(k, tgs.num_nodes);
    for (auto pair : results)
        topkResult.insert(pair.second, pair.first);
    topkResult.print();

    SGLog::log() << "Elapsed time: " << finish << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(finish, {interval_start, interval_end}, topkResult);
    result.all_results = results;
    return result;
}


void TemporalClosenessStream::calcClosenessStreamOrg(TemporalGraphStream &tgs, NodeId nid, vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end) {
    vector <Time> f_time(tgs.num_nodes, MAX_UINT_VALUE);
//    vector <Time> arr_time;
    vector<set<pair<Time, Time>>> ft_timepair(tgs.num_nodes, set<pair<Time, Time>>());

    f_time[nid]=0;

    set < pair< Time, Time > >::iterator it_tp, it_tp_low, it_tp_up, it_tp_1, it_tp_2;

    for(auto & e : tgs.edges) {

        max_it++;

        if(e.t<interval_end){
            if (e.t+e.traversal_time<=interval_end && e.t >=interval_start){
                if (e.u_id == nid){
                    ft_timepair[e.u_id].insert(make_pair(e.t, e.t));
                }

                if(!ft_timepair[e.u_id].empty()){ // the path from x to u is not empty
                    it_tp=ft_timepair[e.u_id].upper_bound(make_pair(e.t, MAX_UINT_VALUE));

                    if(it_tp != ft_timepair[e.u_id].begin()){ //exists some pair arrived at or before t
                        it_tp --;

                        Time a_t=e.t+e.traversal_time;
                        Time s_t=it_tp->second;

                        if(a_t-s_t < f_time[e.v_id])
                            f_time[e.v_id] = a_t-s_t;

                        if(!ft_timepair[e.v_id].empty()){ // the path from x to v is not empty
                            it_tp_1=ft_timepair[e.v_id].lower_bound(make_pair(a_t, s_t));

                            if(it_tp_1 == ft_timepair[e.v_id].begin() ){ // a_t is the smallest arrival time
                                if (it_tp_1->first>a_t){ // the arrival time of it_tp_1 is larger than a_t
                                    it_tp_low=it_tp_1;
                                    for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                        if(it_tp_up->second > s_t){
                                            break;
                                        }
                                    }

                                    ft_timepair[e.v_id].erase(it_tp_low,it_tp_up); //remove useless pairs
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                            }
                            else if (it_tp_1 == ft_timepair[e.v_id].end()) { //a_t is the largest arrival time
                                it_tp_2 = it_tp_1;
                                it_tp_2 --;
                                if(it_tp_2->first == a_t) {
                                    ft_timepair[e.v_id].erase(it_tp_2);
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                                else if (it_tp_2->second < s_t){
                                    ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                }
                            }
                            else {
                                if(it_tp_1->first > a_t) { // it_tp_1->first > a_t
                                    it_tp_2=it_tp_1;
                                    it_tp_2--;

                                    if(it_tp_2->first == a_t) {
                                        it_tp_low=it_tp_1;
                                        for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                            if(it_tp_up->second > s_t){
                                                break;
                                            }
                                        }

                                        ft_timepair[e.v_id].erase(it_tp_2, it_tp_up);
                                        ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                    }
                                    else if (it_tp_2->second < s_t){ // it_tp_2->first < a_t
                                        it_tp_low=it_tp_1;
                                        for(it_tp_up=it_tp_low; it_tp_up != ft_timepair[e.v_id].end(); it_tp_up++){
                                            if(it_tp_up->second > s_t){
                                                break;
                                            }
                                        }

                                        ft_timepair[e.v_id].erase(it_tp_low, it_tp_up);
                                        ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                                    }
                                }
                            }
                        }
                        else {
                            ft_timepair[e.v_id].insert(make_pair(a_t, s_t));
                        }

                    }
                }


            }
        }
        else {
            break;
        }
    }

    double closeness = 0;

    for (NodeId v = 0; v < tgs.num_nodes; ++v) {
        if (f_time[v] > 0 && f_time[v] < MAX_UINT_VALUE) {
            closeness += 1.0 / f_time[v];
        }
    }
    result.emplace_back(nid, closeness);
}



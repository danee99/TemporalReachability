#include "TemporalClosenessRevDurationNoApprox.h"
#include "Paths/LabelPQ.h"
#include "Helpers/SGLog.h"

using namespace std;



void TemporalClosenessRevDurationNoApprox::calculateClosenessForNodeNoApprox(TemporalGraph &tg, NodeId nid, Time interval_start, Time interval_end) {

//    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    auto &minduration = distances.at(nid);

    minduration.at(nid) = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid).push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    unsigned int num_finished = 1;

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited.at(cur->nid)) {
            visited.at(cur->nid) = true;
            minduration.at(cur->nid) = minduration.at(cur->nid) < cur->d ? minduration.at(cur->nid) : cur->d;
            num_finished++;
            if (num_finished == tg.num_nodes) break;
        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

            if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;
            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart.at(e.id) > 0 && edgeMaxStart.at(e.id) >= cur->s) {
                    continue;
                }

                if (cur->s == 0) {
                    edgeMaxStart.at(e.id) = e.t;
                } else {
                    if (edgeMaxStart.at(e.id) < cur->s)
                        edgeMaxStart.at(e.id) = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels.at(e.v_id).begin();
                while (i != nodelabels.at(e.v_id).end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels.at(e.v_id).erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    nodelabels.at(e.v_id).push_back(lnew);
                    minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                    if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                        q.push(lnew);
                    else if (!visited.at(e.v_id))
                        minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                }
            }
        }
    }

}

Result TemporalClosenessRevDurationNoApprox::calculateCloseness(TemporalGraph &tg, unsigned int k, Time interval_start,
                                                                Time interval_end,
                                                                TemporalGraphStream &tgs) {

    for (size_t i = 0; i < tg.num_nodes; ++i) {
        distances.emplace_back(tg.num_nodes, MAX_UINT_VALUE);
    }

    SGLog::log() << "calculation top-k closeness without approx. (calc. all closenesses)" << endl;

    max_it = 0;
    std::vector<std::pair<NodeId, double>> results;
    auto start = std::chrono::high_resolution_clock::now();

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;

    for (TGNode &n : tg.nodes) {
        calculateClosenessForNodeNoApprox(tg, n.id, interval_start, interval_end);
    }

    auto finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = finish - start;


    for (size_t i = 0; i < tg.num_nodes; ++i) {
        double closeness = 0;

        for (NodeId n = 0; n < tg.nodes.size(); ++n) {
            if (distances.at(n).at(i) > 0 && distances.at(n).at(i) < MAX_UINT_VALUE) {
                closeness += 1.0 / distances.at(n).at(i);
            }
        }

        results.emplace_back(i, closeness);
    }


    TopkResult topkResult(k, tg.num_nodes);
    for (auto pair : results)
        topkResult.insert(pair.second, pair.first);
    topkResult.print();

    std::stable_sort(results.begin(), results.end(), [](const pair<NodeId, double> & a, const pair<NodeId, double> & b) -> bool {
        return a.first < b.first;
    });

    SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(elapsed.count(), {interval_start, interval_end}, topkResult);
    result.all_results = results;
    return result;
}

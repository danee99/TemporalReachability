#include "TemporalClosenessDurationNoApprox.h"
#include "Reachability/ReachabilityApprox.h"
#include <queue>
#include <list>
#include "Paths/LabelPQ.h"
#include "Helpers/SGLog.h"
#include "Reachability/TemporalReachability.h"

using namespace std;

Result TemporalClosenessDurationNoApprox::calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, Params const &params, Time interval_start, Time interval_end) {
    SGLog::log() << "calculation top-k closeness without approx. (calc. all closenesses)" << endl;

    max_it = 0;
    std::vector<std::pair<NodeId, double>> results;
    Timer timer;
    timer.start();

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;

    for (TGNode &n : tg.nodes) {
        calculateClosenessForNodeNoApprox(tg, n.id, results, interval_start, interval_end);
//        calculateClosenessForNodeNoApproxSTG(tg, n.id, results, interval_start, interval_end);
    }

    auto finish = timer.stop();

    TopkResult topkResult(params.k, tg.num_nodes);
    for (auto pair : results)
        topkResult.insert(pair.second, pair.first);
    topkResult.print();

    std::stable_sort(results.begin(), results.end(), [](const pair<NodeId, double> & a, const pair<NodeId, double> & b) -> bool {
        return a.first < b.first;
    });

    SGLog::log() << "Elapsed time: " << finish << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(finish, {interval_start, interval_end}, topkResult);
    result.all_results = results;
    return result;
}


void TemporalClosenessDurationNoApprox::calculateClosenessForNodeNoApprox(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration[nid] = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels[nid].push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    unsigned int num_finished = 1;

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited[cur->nid]) {
            visited[cur->nid] = true;
            minduration[cur->nid] = minduration[cur->nid] < cur->d ? minduration[cur->nid] : cur->d;
            num_finished++;
            if (num_finished == tg.num_nodes) break;
        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

            if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;
            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart[e.id] > 0 && edgeMaxStart[e.id] >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart[e.id] = e.t;
                }
                else {
                    if (edgeMaxStart[e.id] < cur->s)
                        edgeMaxStart[e.id] = cur->s;
                }

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels[e.v_id].begin();
                while (i != nodelabels[e.v_id].end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels[e.v_id].erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    nodelabels[e.v_id].push_back(lnew);
                    minduration[e.v_id] = minduration[e.v_id] < lnew->d ? minduration[e.v_id] : lnew->d;
                    if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                        q.push(lnew);
                }
            }
        }
    }

    double closeness = 0;

    for (NodeId n = 0; n < tg.nodes.size(); ++n) {
        if (minduration[n] > 0 && minduration[n] < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration[n];
        }
    }

    result.emplace_back(nid, closeness);
}


void TemporalClosenessDurationNoApprox::calculateClosenessForNodeNoApproxSTG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration[nid] = 0;

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels[nid].push_back(l);

    LabelPQSP2List q;
    q.push(l);

    while (!q.empty()) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                auto lnew = std::make_shared<label>();
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;
                auto i = nodelabels[e.v_id].begin();
                while (i != nodelabels[e.v_id].end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels[e.v_id].erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }
                    ++i;
                }

                if (!dom) {
                    nodelabels[e.v_id].push_back(lnew);
                    minduration[e.v_id] = minduration[e.v_id] < lnew->d ? minduration[e.v_id] : lnew->d;
                    if (tg.nodes[lnew->nid].maxTime >= e.t + e.traversal_time)
                        q.push(lnew);
                }
            }
        }
    }

    double closeness = 0;

    for (NodeId n = 0; n < tg.nodes.size(); ++n) {
        if (minduration[n] > 0 && minduration[n] < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration[n];
        }
    }

    result.emplace_back(nid, closeness);
}


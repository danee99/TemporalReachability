#include "TemporalClosenessDuration.h"
#include "Reachability/ReachabilityApprox.h"
#include "Closeness/ClosenessEstimator.h"
#include "Helpers/SGLog.h"
#include "TemporalClosenessDurationNoApprox.h"
#include <list>
#include <cassert>

using namespace std;

Result TemporalClosenessDuration::calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, const Params &params, Time interval_start, Time interval_end){
    SGLog::log() << "calculation top-k closeness with bounding" << endl;
    Timer timer;

    vector<pair<NodeId, unsigned long>> perm;

    SGLog::log() << "# nodes: " << tg.num_nodes << endl;
    SGLog::log() << "# edges: " << tg.num_edges << endl;

    TopkResult topkResult(params.k, tg.num_nodes);

    max_it = 0;

    timer.start();

    for (auto &n : tg.nodes) {
        perm.emplace_back(n.id, n.adjlist.size());
        if (n.adjlist.empty()) {
            n.maxTime = n.minTime = 0;
        }
    }
    std::sort(perm.begin(), perm.end(), [](const pair<NodeId, unsigned int> & a, const pair<NodeId, unsigned int> & b) -> bool {
        return a.second > b.second;
    });

    for (auto p : perm) {
        calculateClosenessForNodeApprox6(tg, p.first, topkResult, interval_start, interval_end);
//        calculateClosenessForNodeApprox6STG(tg, p.first, topkResult, interval_start, interval_end);
    }
    auto finish = timer.stop();

    topkResult.print();

    SGLog::log() << "Elapsed time: " << finish << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(finish, {interval_start, interval_end}, topkResult);
    return result;
}


void TemporalClosenessDuration::calculateClosenessForNodeApprox6(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid).push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<bool> is_T_vertex(tg.num_nodes, false);

//    double total_reachable = r.at(nid) + 1;
    double total_reachable = tg.num_nodes;//r.at(nid) + 1;

    unsigned int num_f = 0;
    unsigned int num_T = 0;
    double exact_closeness = 0.0;
    double cut_edges_approx = 0.0;

    vector<bool> exactAdded(tg.nodes.size(), false);

//    unsigned long max_size = 0;

    vector<Time> edgeMaxStart(tg.num_edges, 0);

    while (!q.empty() && num_f < tg.num_nodes) {

//        if (q.size() > max_size) max_size = q.size();

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited.at(cur->nid)) {
            visited.at(cur->nid) = true;

            ++num_f;

            if (is_T_vertex[cur->nid]) {
                --num_T;
                cut_edges_approx -= 1.0 / cur->d;
            }

        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

            if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;
            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                if (cur->s > 0 && edgeMaxStart.at(e.id) > 0 && edgeMaxStart.at(e.id) >= cur->s) {
                    continue;
                }

                if (cur->s == 0){
                    edgeMaxStart.at(e.id) = e.t;
                }
                else {
                    if (edgeMaxStart.at(e.id) < cur->s)
                        edgeMaxStart.at(e.id) = cur->s;
                }

                auto lnew = std::make_shared<label>();;
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;

                auto i = nodelabels.at(e.v_id).begin();
                while (i != nodelabels.at(e.v_id).end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels.at(e.v_id).erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }

                    ++i;
                }


                if (!dom) {
                    minduration.at(e.v_id) = minduration.at(e.v_id) < lnew->d ? minduration.at(e.v_id) : lnew->d;
                    nodelabels.at(e.v_id).push_back(lnew);
                    q.push(lnew);

                    if (!is_T_vertex[e.v_id] && !visited[e.v_id]){
                        ++num_T;
                        is_T_vertex[e.v_id] = true;
                    }

                }
            }
        }

        // update estimation for T vertices
        cut_edges_approx = (double)num_T / q.top()->d;

        // update exact closeness
        assert(minduration.at(cur->nid) < MAX_UINT_VALUE);
        if (minduration.at(cur->nid) > 0) {
            if (!exactAdded.at(cur->nid)) {
                exact_closeness += 1.0 / minduration.at(cur->nid);
                exactAdded.at(cur->nid) = true;
            }
        }

        // calculate approx
        if (topkResult.doApproximation()) {

            // calculate rest
//            double rest_approx = double (total_reachable - num_f - num_T) / ((double)cur->d + 2.0 * (tg.minTimeDelta + 1.0)); //todo 2.0
//            double rest_approx = double (total_reachable - num_f - num_T) / ((double)cur->d + 1.0 + tg.minTimeDelta); //todo 2.0
            double rest_approx = double (total_reachable - num_f - num_T) / ((double)q.top()->d + 1.0 + tg.minTimeDelta); //todo 2.0
            double total_approx = exact_closeness + cut_edges_approx + rest_approx;

////            cout << nid << "\t" << minduration.at(cur->n->id) << "\t" << exact_closeness << "\t" << cut_edges_approx << "\t" << rest_approx << "\t" << total_approx << endl;
//            cout << nid << "\t" << exact_closeness << "\t" << cut_edges_approx << "\t" << rest_approx << "\t" << total_approx << "\t" << topkResult.getMinMaxTopk() << endl;
////            cout << nid << "\t" << exact_closeness << "\t" << cut_edges_approx << "\t" << rest_approx << "\t" << total_approx << endl;
//            cout << nid << "\t" << total_reachable << "\t" << num_f << "\t" << num_T << "\t" << min_hop_distance << endl << endl;

            if (total_approx < topkResult.getMinMaxTopk()) {
                return;
            }
        }
    }

    double closeness = exact_closeness;

//    for (NodeId v = 0; v < tg.nodes.size(); ++v) {
//        if (minduration.at(v) > 0 && minduration.at(v) < MAX_UINT_VALUE) {
//            closeness += 1.0 / minduration.at(v);
//        }
//    }

    topkResult.insert(closeness, nid);

//    cout << max_size << " " << (max_size*1.0)/tg.num_nodes << " " << (max_size*1.0)/tg.num_edges << endl;

}

void TemporalClosenessDuration::calculateClosenessForNodeApprox6STG(TemporalGraph &tg, NodeId nid, TopkResult &topkResult, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.nodes.size(), MAX_UINT_VALUE);
    minduration[nid] = 0;

    vector<bool> visited(tg.nodes.size(), false);

    vector<list<shared_ptr<label>>> nodelabels(tg.nodes.size());
    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;
    nodelabels.at(nid).push_back(l);

    LabelPQSP2 q;
    q.push(l);

    vector<bool> is_T_vertex(tg.num_nodes, false);

    double total_reachable = tg.num_nodes;

    unsigned int num_f = 0;
    unsigned int num_T = 0;
    double exact_closeness = 0.0;

    double cut_edges_approx = 0.0;

    vector<bool> exactAdded(tg.nodes.size(), false);

    while (!q.empty() && num_f < tg.num_nodes) {

        auto cur = q.top();
        q.pop();
        if (cur->deleted) {
            continue;
        }

        if (!visited[cur->nid]) {
            visited[cur->nid] = true;

            ++num_f;

            if (is_T_vertex[cur->nid]) {
                --num_T;
                cut_edges_approx -= 1.0 / cur->d;
            }

        }

        for (TemporalEdge &e : tg.nodes[cur->nid].adjlist) {
            ++max_it;

            if (cur->pid == e.v_id) continue;

            if (e.t >= cur->a) {

                auto lnew = std::make_shared<label>();;
                lnew->nid = e.v_id;
                lnew->pid = cur->nid;
                if (cur->s == 0) lnew->s = e.t;
                else lnew->s = cur->s;
                lnew->a = e.t + e.traversal_time;
                lnew->d = lnew->a - lnew->s;

                bool dom = false;

                auto i = nodelabels[e.v_id].begin();
                while (i != nodelabels[e.v_id].end()) {
                    if (((*i)->s < lnew->s && (*i)->a >= lnew->a) || ((*i)->s == lnew->s && (*i)->a > lnew->a)) {
                        (*i)->deleted = true;
                        i = nodelabels[e.v_id].erase(i);
                        continue;
                    }
                    if (((*i)->s >= lnew->s && (*i)->a <= lnew->a) || ((*i)->s == lnew->s && (*i)->a <= lnew->a)) {
                        dom = true;
                        break;
                    }

                    ++i;
                }


                if (!dom) {
                    minduration[e.v_id] = minduration[e.v_id] < lnew->d ? minduration[e.v_id] : lnew->d;
                    nodelabels[e.v_id].push_back(lnew);
                    q.push(lnew);

                    if (!is_T_vertex[e.v_id] && !visited[e.v_id]){
                        ++num_T;
                        is_T_vertex[e.v_id] = true;
                    }

                }
            }
        }

        // update estimation for T vertices
        cut_edges_approx = (double)num_T / q.top()->d;

        // update exact closeness
        if (minduration[cur->nid] > 0) {
            if (!exactAdded[cur->nid]) {
                exact_closeness += 1.0 / minduration[cur->nid];
                exactAdded[cur->nid] = true;
            }
        }

        // calculate approx
        if (topkResult.doApproximation()) {

            // calculate rest
            double rest_approx = (double) (total_reachable - num_f - num_T) / (double)(q.top()->d + 1.0 + tg.minTimeDelta);
            double total_approx = exact_closeness + cut_edges_approx + rest_approx;

            if (total_approx < topkResult.getMinMaxTopk()) {
                return;
            }
        }
    }

    double closeness = exact_closeness;
    topkResult.insert(closeness, nid);
}


//
// Created by lutz on 31.01.20.
//

#ifndef CENTRALITY_TEMPORALCLOSENESSSTREAM_H
#define CENTRALITY_TEMPORALCLOSENESSSTREAM_H

#include "TemporalGraph/TemporalGraphs.h"
#include "Helpers/TopkResult.h"

class TemporalClosenessStream {

public:

    Result calculateCloseness(TemporalGraphStream &tgs, unsigned int k, bool unit, Time interval_start, Time interval_end);

private:

    void calculateClosenessDurationNoApproxTGS(TemporalGraphStream &tgs, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);
    void calculateClosenessDurationNoApproxTGSVectorized(TemporalGraphStream &tgs, std::vector<std::pair<NodeId, double>> &result);

    void calculateClosenessDurationNoApproxTGS2(TemporalGraphStream &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);

    void calcClosenessStreamOrg(TemporalGraphStream &tgs, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);
    void calcClosenessStreamOrgVectorized(TemporalGraphStream &tgs, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);
    void calcStreamTES(TemporalGraphStream &tg, TESvec &tes, NodeId nid, std::vector<std::pair<NodeId, double>> &result);

    unsigned long max_it = 0;
};


#endif //CENTRALITY_TEMPORALCLOSENESSSTREAM_H

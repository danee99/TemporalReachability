#include "TemporalClosenessStreamJump.h"
#include "Paths/LabelPQ.h"
#include "Helpers/SGLog.h"
#include <chrono>
#include <list>

using namespace std;

Result TemporalClosenessStreamJump::calculateCloseness(TemporalGraphStream &tgs, unsigned int k, bool unit, Time interval_start, Time interval_end) {
    max_it = 0;

    auto start = std::chrono::steady_clock::now();

    SGLog::log() << "# nodes: " << tgs.num_nodes << endl;
    SGLog::log() << "# edges: " << tgs.edges.size() << endl;

    TopkResult topkResult(k, tgs.num_nodes);

    init(tgs);

    for (NodeId nid = 0; nid < tgs.num_nodes; ++nid) {
        if (unit)
            calculateClosenessDurationNoApproxTGS(tgs, nid, topkResult, interval_start, interval_end);
        else
            calculateClosenessDurationNoApproxTGS2(tgs, nid, topkResult, interval_start, interval_end);
    }
    auto finish = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed = finish - start;

    topkResult.print();

    SGLog::log() << "Elapsed time: " << elapsed.count() << " s\n";
    SGLog::log() << "Iterations: " << max_it << endl;

    Result result(elapsed.count(), {interval_start, interval_end}, topkResult);
    return result;
}



void TemporalClosenessStreamJump::calculateClosenessDurationNoApproxTGS(TemporalGraphStream &tgs, NodeId nid, TopkResult &result, Time interval_start, Time interval_end) {
    vector<Time> minduration(tgs.num_nodes, MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    vector<list<label>> labels(tgs.num_nodes, list<label>());

    label l;
    l.a = l.s = l.d = 0;
    l.nid = nid;

    labels[nid].push_back(l);

    for (unsigned long p = start_pos[nid]; p < tgs.edges.size(); ++p) {
        auto &e = tgs.edges.at(p);

        auto u_id = e.u_id;
        auto v_id = e.v_id;
        auto et = e.t;
//        auto u_id = tgs.uids[p];
//        auto v_id = tgs.vids[p];
//        auto et = tgs.ts[p];

        max_it++;
//        if (e.t < interval_start || e.t + 1 > interval_end) continue;

        if (labels[u_id].empty()) {
            continue;
        }

        auto i = labels[u_id].begin();
        if (labels[u_id].size() > 1 && (*i).a <= et) {
            auto i2 = labels[u_id].begin();
            ++i2;

            while (true) {
                if ((*i2).a <= et) i = labels[u_id].erase(i);

                ++i2;
                if (i2 == labels[u_id].end() || (*i2).a > et) {
                    break;
                }
            }

        }
        if (i == labels[u_id].end() || (*i).a > et) continue;


        label a;
        a.nid = v_id;
        if ((*i).nid == nid) a.s = et;
        else a.s = (*i).s;
        a.a = et + 1;
        a.d = a.a - a.s;


        if (labels[v_id].empty()) {
            labels[v_id].push_back(a);
            minduration[v_id] = a.d;
            continue;
        }

        auto b = labels[v_id].back();
        if ((a.s < b.s && a.a >= b.a) || (a.s == b.s && a.a > b.a)) {
            // b dominates a
            continue;
        } else if ((b.s < a.s && b.a >= a.a) || (b.s == a.s && b.a > a.a)) {
            // a dominates b
            labels[v_id].pop_back();
            labels[v_id].push_back(a);
            minduration[v_id] = minduration[v_id] < a.d ? minduration[v_id] : a.d;
        } else {
            // keep both
            labels[v_id].push_back(a);
            minduration[v_id] = minduration[v_id] < a.d ? minduration[v_id] : a.d;
        }
    }

    double closeness = 0;

    for (NodeId v = 0; v < tgs.num_nodes; ++v) {
        if (minduration[v] > 0 && minduration[v] < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration.at(v);
        }
    }

    result.insert(closeness, nid);

}

void TemporalClosenessStreamJump::calculateClosenessDurationNoApproxTGS2(TemporalGraphStream &tg, NodeId nid, TopkResult &result, Time interval_start, Time interval_end) {

    vector<Time> minduration(tg.num_nodes, MAX_UINT_VALUE);
    minduration.at(nid) = 0;

    auto cmp = [](const shared_ptr<label>& a, const shared_ptr<label>& b) { return a->a < b->a; };
    vector<set<shared_ptr<label>, decltype(cmp)>> labels(tg.num_nodes, set<shared_ptr<label>, decltype(cmp)>(cmp));

    auto l = std::make_shared<label>();
    l->a = l->s = l->d = 0;
    l->nid = nid;

    labels.at(nid).insert(l);

    for (unsigned long p = start_pos.at(nid); p < tg.edges.size(); ++p) {
        auto &e = tg.edges.at(p);
        max_it++;

        if (e.t < interval_start || e.t + e.traversal_time > interval_end) continue;

        auto k = std::make_shared<label>();
        k->a = e.t;
        auto i = labels.at(e.u_id).upper_bound(k);

        if (i != labels.at(e.u_id).begin() ) {
            --i;
        }
        if (i == labels.at(e.u_id).end()) {
            continue;
        }
        if (e.t < (*i)->a) continue;
        assert(e.t >= (*i)->a);

        auto a = std::make_shared<label>();
        a->nid = e.v_id;
        if ((*i)->nid == nid) a->s = e.t;
        else a->s = (*i)->s;
        a->a = e.t + e.traversal_time;
        a->d = a->a - a->s;


//        auto k2 = std::make_shared<label>();
//        k2->s = a->s;
//        auto j = labels.at(e.u_id).lower_bound(k2);
//        if (j != labels.at(e.v_id).end()) {
//            if ((*j)->a > a->a) {
//                minduration.at(e.v_id) = a->d;
//                (*j)->a = a->a;
//            }
//        }

        if (labels.at(e.v_id).empty()) {
            labels.at(e.v_id).insert(a);
            minduration.at(e.v_id) = a->d;
            continue;
        }

        bool dom = false;
        auto b = labels.at(e.v_id).begin();
        while (b != labels.at(e.v_id).end()) {
//            if ((a->s == (*b)->s && a->a < (*b)->a)) {
//                (*b)->a = a->a;
//                minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
//                dom = true;
//                break;
//            }
            if ((a->s <= (*b)->s && a->a >= (*b)->a) || (a->s == (*b)->s && a->a > (*b)->a)) {
                // b dominates a
                dom = true;
                break;
            } else if (((*b)->s < a->s && (*b)->a >= a->a) || ((*b)->s == a->s && (*b)->a > a->a)) {
                // a dominates b
                b = labels.at(e.v_id).erase(b);
            } else {
                ++b;
            }
        }

        if (!dom) {
            labels.at(e.v_id).insert(a);
            minduration.at(e.v_id) = minduration.at(e.v_id) < a->d ? minduration.at(e.v_id) : a->d;
        }
    }

    double closeness = 0;

    for (NodeId v = 0; v < tg.num_nodes; ++v) {
        if (minduration.at(v) > 0 && minduration.at(v) < MAX_UINT_VALUE) {
            closeness += 1.0 / minduration.at(v);
        }
    }

    result.insert(closeness, nid);

}

void TemporalClosenessStreamJump::init(TemporalGraphStream &tgs) {
    start_pos.resize(tgs.num_nodes, MAX_UINT_VALUE);
    unsigned long p = 0;
    for (auto &e : tgs.edges) {
        if (start_pos.at(e.u_id) == MAX_UINT_VALUE) {
            start_pos.at(e.u_id) = p;
        }
        p++;
    }
}


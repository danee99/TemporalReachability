//
// Created by lutz on 03.02.20.
//

#ifndef CENTRALITY_TEMPORALCLOSENESSDURATIONNOAPPROX_H
#define CENTRALITY_TEMPORALCLOSENESSDURATIONNOAPPROX_H

#include <Helpers/Params.h>
#include "TemporalGraph/TemporalGraphs.h"
#include "Helpers/TopkResult.h"
#include "Paths/LabelPQ.h"


class TemporalClosenessDurationNoApprox {

public:

    Result calculateCloseness(TemporalGraph &tg, TemporalGraphStream& tgs, Params const &params, Time interval_start, Time interval_end);

private:

    void calculateClosenessForNodeNoApprox(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);
    void calculateClosenessForNodeNoApproxSTG(TemporalGraph &tg, NodeId nid, std::vector<std::pair<NodeId, double>> &result, Time interval_start, Time interval_end);

    unsigned long max_it = 0;

};


#endif //CENTRALITY_TEMPORALCLOSENESSDURATIONNOAPPROX_H

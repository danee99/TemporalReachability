#include <TemporalGraph/TemporalGraphStreamProvider.h>
#include <Closeness/TemporalClosenessDuration.h>
#include <Closeness/ClosenessEstimator.h>
#include <Closeness/TemporalClosenessStream.h>
#include <Closeness/TemporalClosenessDurationNoApprox.h>
#include <Helpers/SGLog.h>
#include "TemporalGraph/TemporalGraphs.h"
#include <iomanip>
#include <Paths/FastestPath.h>
#include <cmath>
#include <Closeness/TemporalClosenessStreamJump.h>
#include <Helpers/Params.h>
#include <Reachability/ReachabilityEvaluation.h>
#include <SISim/SIExperiment.h>
#include <Closeness/TemporalClosenessDurationHeuristics.h>
#include "Helpers/HelperFunctions.h"

using namespace std;

void runIntervals(Params& params, TemporalGraphStream &tgs, TemporalGraph &tg) {

    Time interval_start = tgs.edges[0].t;
    Time interval_end = tgs.edges.back().t + tgs.edges.back().traversal_time;

    switch (params.mode) {
        case duration_no_approx : {
            if (params.use_heuristic > 0) {
                TemporalClosenessDurationHeuristics tcdna;
                auto result = tcdna.calculateClosenessNoBounding(tg, tgs, params, interval_start, interval_end);
                if (!params.result_filename.empty())
                    HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            } else {
                TemporalClosenessDurationNoApprox tcdna;
                auto result = tcdna.calculateCloseness(tg, tgs, params, interval_start, interval_end);
                if (!params.result_filename.empty())
                    HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            }
            break;
        }
        case rev_duration_no_approx : {
            TemporalClosenessDurationNoApprox tcdna;
            auto rtg = tg.toReverseTemporalGraph(interval_start, interval_end);
            auto rtgs = rtg.toStream();
            auto result = tcdna.calculateCloseness(rtg, rtgs, params, interval_start, interval_end);
            if (!params.result_filename.empty())
                HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            break;
        }
        case duration_topk : {
            if (params.use_heuristic > 0) {
                TemporalClosenessDuration tcd;
                auto result = tcd.calculateCloseness(tg, tgs, params, interval_start, interval_end);
                if (!params.result_filename.empty())
                    HF::writeVectorToFile(params.result_filename, result.topkResult.getResults(), ",");
            } else {
                TemporalClosenessDuration tcd;
                auto result = tcd.calculateCloseness(tg, tgs, params, interval_start, interval_end);
                if (!params.result_filename.empty())
                    HF::writeVectorToFile(params.result_filename, result.topkResult.getResults(), ",");
            }
            break;
        }
        case duration_baseline : {
            TemporalClosenessStream tcs;
            auto result = tcs.calculateCloseness(tgs, params.k, params.unit, interval_start, interval_end);
            if (!params.result_filename.empty())
                HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            break;
        }
        case duration_streamjump : {
            TemporalClosenessStreamJump tcs;
            auto result = tcs.calculateCloseness(tgs, params.k, params.unit, interval_start, interval_end);
            if (!params.result_filename.empty())
                HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            break;
        }
        case duration_sampling : {
            auto result = ClosenessEstimator::estimateCloseness(tg, params.k, params.sampling_size, interval_start, interval_end);
            if (!params.result_filename.empty())
                HF::writeVectorToFile(params.result_filename, result.all_results, ",");
            break;
        }
        case fastest_path : {
            FastestPath fp(tgs);
            fp.initStartEndVertices(params.k, params.cs_steps);
            fp.compareFastestPathAlgorithms();
            break;
        }
        case fastest_path_highdegree : {
            FastestPath fp(tgs);
            fp.initStartEndVertices(params.k, params.cs_steps);
            fp.compareFastestPathAlgorithmsHighDegree();
            break;
        }
        case reachability_test : {
            reachability_approx_test(tgs, tg, params);
            break;
        }
        case reachability_time_test : {
            reachability_running_time_test(tgs, tg, params);
            break;
        }
        case compare_results_eps : {
            if (params.result_filename.empty() || params.cmp_filename.empty()) break;
            ResultFile resultFile(params.result_filename);
            resultFile.load();
            ResultFile cmpFile(params.cmp_filename);
            cmpFile.load();
            cmpFile.compare(resultFile.getResults(), params.k);
            break;
        }
        case compare_results_cover : {
            if (params.result_filename.empty() || params.cmp_filename.empty()) break;
            ResultFile resultFile(params.result_filename);
            if (params.reachability_mode == 0)
                resultFile.load();
            else
                resultFile.loadReach();
            ResultFile cmpFile(params.cmp_filename);
            cmpFile.load();
            cmpFile.compareCover(resultFile.getResults(), params.k);
            break;
        }
        case case_study : {
            si_experiment(tgs, tg, params);
            break;
        }
        case tg_statistics : {
            auto tgstats = HF::getTemporalGraphStreamsStatistics(tgs);
            SGLog::log() << tgstats;
            break;
        }
        case stats_to_file : {
            HF::writeStatisticsToFile(tgs, params.result_filename);
            break;
        }
        default :
            show_help();
    }
}



int main(int argc, char* argv[]) {
    srand((unsigned)time(nullptr) );

    vector<string> args;
    for (size_t i = 1; i < argc; ++i)
        args.emplace_back(argv[i]);


    Params params;
    if (!params.parseArgs(args))
        show_help();

    if (params.random_seed != 0)
        srand(params.random_seed);

    std::cout << std::setprecision(10);

    TemporalGraphStreamProvider p;
    p.loadTemporalGraph(params.dataset_path, params.directed);

    TemporalGraph tg = p.getTG();
    TemporalGraphStream tgs = p.getTGS();

    runIntervals(params, tgs, tg);

    return 0;
}